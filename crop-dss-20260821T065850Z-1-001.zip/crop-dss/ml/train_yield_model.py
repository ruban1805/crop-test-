"""
ml/train_yield_model.py
=======================
Training script for the RandomForest/XGBoost yield prediction model.

Data source: data.gov.in historical crop yield data (India)
  - District-wise crop production: https://data.gov.in/catalog/district-wise-season-wise-crop-production
  - Download CSV and place at ml/data/crop_yield.csv

Features used:
  - soil_pH, clay_pct, sand_pct, organic_carbon
  - annual_rainfall_mm, avg_temp_C
  - season (encoded), crop_name (encoded)
  - land_area_ha

Target: yield_t_ha (yield in tonnes per hectare)

Output: ml/models/yield_model.pkl + ml/models/preprocessor.pkl
"""

from __future__ import annotations
import os
import json
import pickle
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import mean_absolute_error, r2_score

warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
BASE_DIR   = Path(__file__).parent
DATA_PATH  = BASE_DIR / "data" / "crop_yield.csv"
MODEL_DIR  = BASE_DIR / "models"
MODEL_PATH = MODEL_DIR / "yield_model.pkl"
META_PATH  = MODEL_DIR / "model_meta.json"

MODEL_DIR.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Synthetic dataset generator (fallback when real data not yet downloaded)
# ---------------------------------------------------------------------------

def generate_synthetic_data(n_samples: int = 5000) -> pd.DataFrame:
    """
    Generate synthetic but agronomically consistent training data.
    Used for smoke-testing the pipeline before real data is loaded.
    """
    rng = np.random.default_rng(42)

    crops = [
        "paddy", "maize", "sorghum", "pearl_millet", "finger_millet",
        "groundnut", "sesame", "castor", "blackgram", "greengram",
        "cowpea", "sugarcane", "cotton", "banana", "turmeric",
        "onion", "tomato", "sunflower", "tapioca",
    ]

    # Crop-specific yield ranges (tonnes/ha)
    yield_ranges = {
        "paddy": (2.0, 6.0), "maize": (3.0, 8.0), "sorghum": (1.5, 4.5),
        "pearl_millet": (1.0, 3.5), "finger_millet": (1.5, 4.0),
        "groundnut": (1.2, 3.5), "sesame": (0.3, 0.9), "castor": (1.0, 2.5),
        "blackgram": (0.6, 1.5), "greengram": (0.5, 1.2), "cowpea": (0.6, 1.8),
        "sugarcane": (60.0, 120.0), "cotton": (1.0, 2.5), "banana": (20.0, 45.0),
        "turmeric": (15.0, 25.0), "onion": (15.0, 30.0), "tomato": (25.0, 50.0),
        "sunflower": (0.9, 2.0), "tapioca": (20.0, 40.0),
    }

    seasons = ["kharif", "rabi", "perennial"]

    records = []
    for _ in range(n_samples):
        crop = rng.choice(crops)
        y_lo, y_hi = yield_ranges[crop]
        season = rng.choice(seasons)

        soil_pH       = rng.uniform(5.0, 8.5)
        clay_pct      = rng.uniform(10, 50)
        sand_pct      = rng.uniform(10, 70)
        organic_carbon = rng.uniform(0.5, 3.0)
        rainfall_mm   = rng.uniform(300, 2000)
        avg_temp_C    = rng.uniform(18, 40)

        # Yield influenced by conditions (closer to optimum → higher yield)
        noise = rng.normal(0, 0.15)
        base_yield = rng.uniform(y_lo, y_hi)
        # Penalise extreme pH
        ph_penalty = abs(soil_pH - 6.8) * 0.1
        yield_val = max(y_lo * 0.5, base_yield * (1 - ph_penalty) + noise)
        yield_val = min(yield_val, y_hi * 1.1)

        records.append({
            "crop_name": crop,
            "season": season,
            "soil_pH": round(soil_pH, 2),
            "clay_pct": round(clay_pct, 1),
            "sand_pct": round(sand_pct, 1),
            "organic_carbon": round(organic_carbon, 2),
            "annual_rainfall_mm": round(rainfall_mm, 0),
            "avg_temp_C": round(avg_temp_C, 1),
            "yield_t_ha": round(yield_val, 3),
        })

    return pd.DataFrame(records)


# ---------------------------------------------------------------------------
# Training pipeline
# ---------------------------------------------------------------------------

def load_or_generate_data() -> pd.DataFrame:
    """Load real data if available, else generate synthetic."""
    if DATA_PATH.exists():
        print(f"[ML] Loading real data from {DATA_PATH}")
        df = pd.read_csv(DATA_PATH)
        # Standardise column names (data.gov.in varies)
        rename_map = {
            "Crop": "crop_name",
            "Season": "season",
            "State_Name": "state",
            "District_Name": "district",
            "Crop_Year": "year",
            "Area": "area_ha",
            "Production": "production_t",
        }
        df.rename(columns={k: v for k, v in rename_map.items() if k in df.columns}, inplace=True)
        if "area_ha" in df.columns and "production_t" in df.columns:
            df["yield_t_ha"] = df["production_t"] / df["area_ha"].replace(0, np.nan)
            df.dropna(subset=["yield_t_ha"], inplace=True)
        # Add dummy soil/weather columns for initial model (will be filled from APIs later)
        if "soil_pH" not in df.columns:
            df["soil_pH"]             = np.random.uniform(6.0, 7.5, len(df))
            df["clay_pct"]            = np.random.uniform(20, 40, len(df))
            df["sand_pct"]            = np.random.uniform(20, 40, len(df))
            df["organic_carbon"]      = np.random.uniform(0.8, 2.5, len(df))
            df["annual_rainfall_mm"]  = np.random.uniform(600, 1400, len(df))
            df["avg_temp_C"]          = np.random.uniform(25, 35, len(df))
        return df
    else:
        print("[ML] Real data not found. Generating synthetic training data.")
        return generate_synthetic_data()


def build_pipeline(model_type: str = "random_forest") -> Pipeline:
    """Build sklearn pipeline with preprocessor + regressor."""
    numeric_features = [
        "soil_pH", "clay_pct", "sand_pct", "organic_carbon",
        "annual_rainfall_mm", "avg_temp_C",
    ]
    categorical_features = ["crop_name", "season"]

    preprocessor = ColumnTransformer([
        ("num", StandardScaler(), numeric_features),
        ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False),
         categorical_features),
    ])

    if model_type == "gradient_boost":
        regressor = GradientBoostingRegressor(
            n_estimators=200,
            max_depth=5,
            learning_rate=0.05,
            subsample=0.8,
            random_state=42,
        )
    else:
        regressor = RandomForestRegressor(
            n_estimators=200,
            max_depth=12,
            min_samples_leaf=5,
            random_state=42,
            n_jobs=-1,
        )

    return Pipeline([
        ("preprocessor", preprocessor),
        ("regressor", regressor),
    ])


def train(model_type: str = "random_forest") -> dict:
    """Full training run. Returns evaluation metrics dict."""
    df = load_or_generate_data()

    feature_cols = [
        "crop_name", "season", "soil_pH", "clay_pct", "sand_pct",
        "organic_carbon", "annual_rainfall_mm", "avg_temp_C",
    ]
    target_col = "yield_t_ha"

    # Keep only rows with required columns
    df = df[feature_cols + [target_col]].dropna()
    df[target_col] = df[target_col].clip(lower=0.01)

    X = df[feature_cols]
    y = df[target_col]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    print(f"[ML] Training set: {len(X_train)} samples | Test set: {len(X_test)} samples")

    pipeline = build_pipeline(model_type)
    pipeline.fit(X_train, y_train)

    # Evaluation
    y_pred = pipeline.predict(X_test)
    mae  = mean_absolute_error(y_test, y_pred)
    r2   = r2_score(y_test, y_pred)
    cv_r2 = cross_val_score(pipeline, X, y, cv=5, scoring="r2").mean()

    metrics = {
        "model_type": model_type,
        "n_train": len(X_train),
        "n_test": len(X_test),
        "mae_t_ha": round(float(mae), 4),
        "r2": round(float(r2), 4),
        "cv_r2_mean": round(float(cv_r2), 4),
        "feature_cols": feature_cols,
    }

    print(f"[ML] MAE: {mae:.3f} t/ha | R²: {r2:.3f} | CV-R²: {cv_r2:.3f}")

    # Save model + metadata
    with open(MODEL_PATH, "wb") as f:
        pickle.dump(pipeline, f)
    with open(META_PATH, "w") as f:
        json.dump(metrics, f, indent=2)

    print(f"[ML] Model saved to {MODEL_PATH}")
    return metrics


# ---------------------------------------------------------------------------
# Inference helper (used by engine.py)
# ---------------------------------------------------------------------------

_cached_pipeline = None


def load_model():
    global _cached_pipeline
    if _cached_pipeline is None:
        if not MODEL_PATH.exists():
            print("[ML] Model not trained yet; run train_yield_model.py first.")
            return None
        with open(MODEL_PATH, "rb") as f:
            _cached_pipeline = pickle.load(f)
    return _cached_pipeline


def predict_yield_scores(
    land_features: dict,
    crop_names: list,
) -> dict:
    """
    Predict yield probability (normalised 0-1) for each crop.

    Parameters
    ----------
    land_features : dict with soil/weather keys (soil_pH, clay_pct, etc.)
    crop_names    : list of crop names to score

    Returns
    -------
    dict: crop_name → normalised yield score (0-1)
    """
    pipeline = load_model()
    if pipeline is None:
        return {c: 0.5 for c in crop_names}  # neutral default

    rows = [
        {
            "crop_name": crop,
            "season": "kharif",  # TODO: use actual season
            **land_features,
        }
        for crop in crop_names
    ]
    df = pd.DataFrame(rows)
    preds = pipeline.predict(df)

    # Normalise within this batch: highest yield → 1.0
    max_pred = max(preds) if max(preds) > 0 else 1.0
    scores = {crop: round(float(pred) / max_pred, 4) for crop, pred in zip(crop_names, preds)}
    return scores


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Train crop yield prediction model")
    parser.add_argument("--model", default="random_forest",
                        choices=["random_forest", "gradient_boost"])
    args = parser.parse_args()
    metrics = train(args.model)
    print("\nTraining complete:")
    for k, v in metrics.items():
        print(f"  {k}: {v}")
