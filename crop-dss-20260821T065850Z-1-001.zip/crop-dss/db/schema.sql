-- =============================================================================
-- Crop Decision Support System — PostgreSQL Schema
-- =============================================================================
-- Run with: psql -U <user> -d crop_dss -f schema.sql
-- Create DB first: createdb crop_dss
-- =============================================================================

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS postgis;           -- for geospatial queries (optional)

-- =============================================================================
-- 1. CROP REFERENCE DATABASE
--    Mirrors the Python HashMap (crop_database.py) but persisted in PostgreSQL.
--    Farmers and agronomists can update these values without redeploying code.
-- =============================================================================

CREATE TABLE IF NOT EXISTS crops (
    id                    SERIAL PRIMARY KEY,
    crop_name             VARCHAR(100) UNIQUE NOT NULL,
    display_name_en       VARCHAR(150) NOT NULL,
    display_name_ta       VARCHAR(150),

    -- Soil requirements
    soil_ph_min           NUMERIC(4,2) NOT NULL,
    soil_ph_max           NUMERIC(4,2) NOT NULL,

    -- Water requirements
    water_need_mm         INTEGER NOT NULL,          -- total seasonal mm
    min_rainfall_mm       INTEGER NOT NULL,
    max_rainfall_mm       INTEGER NOT NULL,

    -- Temperature range
    temp_min_c            NUMERIC(5,2) NOT NULL,
    temp_max_c            NUMERIC(5,2) NOT NULL,

    -- Agronomics
    season                VARCHAR(20) NOT NULL CHECK (season IN ('kharif','rabi','zaid','perennial')),
    duration_days         INTEGER NOT NULL,
    nitrogen_need         VARCHAR(10) CHECK (nitrogen_need IN ('low','medium','high')),

    -- Economics
    market_price_per_kg   NUMERIC(8,2),             -- INR/kg; updated periodically
    yield_min_t_ha        NUMERIC(6,2),
    yield_max_t_ha        NUMERIC(6,2),

    -- Compatible soil types and climate zones (stored as arrays)
    suitable_soil_types   TEXT[],
    climate_zones         TEXT[],

    -- UI content
    description_en        TEXT,
    description_ta        TEXT,

    created_at            TIMESTAMP DEFAULT NOW(),
    updated_at            TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_crops_name ON crops(crop_name);
CREATE INDEX idx_crops_season ON crops(season);


-- =============================================================================
-- 2. LAND PROFILES
--    Stores each farmer's land parcel data (submitted via app).
-- =============================================================================

CREATE TABLE IF NOT EXISTS land_profiles (
    id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id               UUID,                        -- FK to users table (if auth added)
    label                 VARCHAR(200),                -- farmer-given name for this land

    latitude              NUMERIC(10,7) NOT NULL,
    longitude             NUMERIC(10,7) NOT NULL,
    land_size_ha          NUMERIC(10,3) NOT NULL,

    -- Manual inputs
    water_source          VARCHAR(20) NOT NULL DEFAULT 'rain_fed'
                          CHECK (water_source IN ('rain_fed','irrigated','well')),
    manual_soil_ph        NUMERIC(4,2),
    manual_soil_type      VARCHAR(50),

    -- API-fetched soil data (cached here to avoid repeated calls)
    api_soil_ph           NUMERIC(4,2),
    api_soil_type         VARCHAR(50),
    soil_clay_pct         NUMERIC(5,2),
    soil_sand_pct         NUMERIC(5,2),
    soil_organic_carbon   NUMERIC(6,3),
    soil_data_source      VARCHAR(50),
    soil_fetched_at       TIMESTAMP,

    -- API-fetched weather data (cached)
    annual_rainfall_mm    NUMERIC(8,2),
    avg_temp_c            NUMERIC(5,2),
    weather_data_source   VARCHAR(50),
    weather_fetched_at    TIMESTAMP,

    -- NDVI
    ndvi                  NUMERIC(5,3),
    ndvi_class            VARCHAR(20),
    ndvi_source           VARCHAR(50),
    ndvi_fetched_at       TIMESTAMP,

    -- Image analysis
    image_filename        VARCHAR(255),
    vegetation_cover_pct  NUMERIC(5,2),
    soil_color_class      VARCHAR(50),
    waterlogging_risk     VARCHAR(20),
    lulc_class            VARCHAR(100),

    created_at            TIMESTAMP DEFAULT NOW(),
    updated_at            TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_land_profiles_location ON land_profiles(latitude, longitude);
CREATE INDEX idx_land_profiles_user ON land_profiles(user_id);


-- =============================================================================
-- 3. QUERY HISTORY / RECOMMENDATION RESULTS
--    Every call to /analyze-land is stored here for audit, analytics, and
--    farmer history ("what did the app recommend last season?").
-- =============================================================================

CREATE TABLE IF NOT EXISTS recommendations (
    id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    land_profile_id       UUID REFERENCES land_profiles(id) ON DELETE SET NULL,
    request_id            VARCHAR(20),                 -- short UUID from API

    -- Snapshot of inputs used for this analysis
    soil_ph_used          NUMERIC(4,2),
    soil_type_used        VARCHAR(50),
    rainfall_used_mm      NUMERIC(8,2),
    avg_temp_used_c       NUMERIC(5,2),
    ahp_weights           JSONB,
    ahp_cr                NUMERIC(6,4),

    -- Number of crops in/out of MCDM
    n_candidates          INTEGER,
    n_eliminated          INTEGER,
    eliminated_crops      JSONB,                       -- [{crop, reason}, ...]

    -- ML blend settings
    ml_blend_applied      BOOLEAN DEFAULT FALSE,
    ml_blend_weight       NUMERIC(3,2),

    created_at            TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_recommendations_land ON recommendations(land_profile_id);
CREATE INDEX idx_recommendations_created ON recommendations(created_at DESC);


-- =============================================================================
-- 4. RECOMMENDATION ITEMS
--    Individual crops within a recommendation set (one row per ranked crop).
-- =============================================================================

CREATE TABLE IF NOT EXISTS recommendation_items (
    id                    SERIAL PRIMARY KEY,
    recommendation_id     UUID REFERENCES recommendations(id) ON DELETE CASCADE,
    rank                  SMALLINT NOT NULL,
    crop_name             VARCHAR(100) NOT NULL,
    suitability_percent   NUMERIC(5,2) NOT NULL,
    top_reasons           TEXT[],
    worst_factors         TEXT[],
    expected_yield_range  VARCHAR(50),
    best_sowing_window    VARCHAR(100),
    market_price_per_kg   NUMERIC(8,2),
    topsis_scores         JSONB,                       -- per-criterion scores
    ml_yield_score        NUMERIC(5,4)
);

CREATE INDEX idx_rec_items_recommendation ON recommendation_items(recommendation_id);
CREATE INDEX idx_rec_items_crop ON recommendation_items(crop_name);


-- =============================================================================
-- 5. USERS (minimal — for future auth)
-- =============================================================================

CREATE TABLE IF NOT EXISTS users (
    id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    phone_number          VARCHAR(20) UNIQUE,          -- India: +91XXXXXXXXXX
    name                  VARCHAR(200),
    preferred_language    VARCHAR(5) DEFAULT 'en',
    district              VARCHAR(100),
    state                 VARCHAR(100) DEFAULT 'Tamil Nadu',
    created_at            TIMESTAMP DEFAULT NOW()
);


-- =============================================================================
-- 6. MARKET PRICES (time series — for trend charts)
-- =============================================================================

CREATE TABLE IF NOT EXISTS market_prices (
    id                    SERIAL PRIMARY KEY,
    crop_name             VARCHAR(100) NOT NULL,
    market_name           VARCHAR(200),               -- mandi name
    district              VARCHAR(100),
    price_per_kg          NUMERIC(8,2) NOT NULL,
    recorded_date         DATE NOT NULL,
    source                VARCHAR(50) DEFAULT 'data.gov.in',
    created_at            TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_market_prices_crop_date ON market_prices(crop_name, recorded_date DESC);


-- =============================================================================
-- Trigger: update `updated_at` automatically
-- =============================================================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_crops_updated_at
    BEFORE UPDATE ON crops
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_land_profiles_updated_at
    BEFORE UPDATE ON land_profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
