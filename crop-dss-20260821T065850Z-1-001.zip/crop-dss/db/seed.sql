-- =============================================================================
-- Seed data: Crop reference database
-- Run after schema.sql:  psql -U <user> -d crop_dss -f seed.sql
-- =============================================================================

INSERT INTO crops (
    crop_name, display_name_en, display_name_ta,
    soil_ph_min, soil_ph_max,
    water_need_mm, min_rainfall_mm, max_rainfall_mm,
    temp_min_c, temp_max_c,
    season, duration_days, nitrogen_need,
    market_price_per_kg, yield_min_t_ha, yield_max_t_ha,
    suitable_soil_types, climate_zones,
    description_en, description_ta
) VALUES

-- CEREALS
('paddy', 'Paddy (Rice)', 'நெல்',
 5.5, 7.0, 1200, 900, 2500, 20, 38, 'kharif', 120, 'high',
 21.00, 2.0, 6.0,
 ARRAY['clay', 'clay_loam', 'loam'],
 ARRAY['Am', 'Aw', 'Cwa'],
 'Staple cereal; needs flooded or waterlogged conditions.',
 'தமிழ்நாட்டின் முக்கிய தானியம்; நீர் தேங்கும் நிலம் தேவை.'),

('maize', 'Maize (Corn)', 'மக்காச்சோளம்',
 5.8, 7.5, 500, 400, 900, 18, 35, 'kharif', 90, 'high',
 18.00, 3.0, 8.0,
 ARRAY['loam', 'sandy_loam', 'clay_loam'],
 ARRAY['Am', 'Aw', 'BSh', 'Cwa'],
 'Versatile cereal; used as food, feed, and industrial starch.',
 'உணவு, தீவனம் மற்றும் தொழில்துறைக்கு பயன்படுகிறது.'),

('sorghum', 'Sorghum (Cholam)', 'சோளம்',
 5.5, 8.5, 350, 300, 750, 25, 40, 'kharif', 100, 'medium',
 22.00, 1.5, 4.5,
 ARRAY['loam', 'sandy_loam', 'vertisol'],
 ARRAY['BSh', 'BWh', 'Aw'],
 'Drought-tolerant cereal; ideal for dryland farming.',
 'வறட்சி தாங்கும் தானியம்; நிலத்தடி நீர் தேவை குறைவு.'),

('pearl_millet', 'Pearl Millet (Kambu)', 'கம்பு',
 5.5, 8.0, 300, 250, 600, 25, 42, 'kharif', 75, 'medium',
 23.00, 1.0, 3.5,
 ARRAY['sandy_loam', 'loam'],
 ARRAY['BSh', 'BWh'],
 'Heat and drought tolerant millet; short-cycle crop.',
 'வெப்பம் மற்றும் வறட்சியை தாங்கும் குறுகிய கால பயிர்.'),

('finger_millet', 'Finger Millet (Ragi)', 'கேழ்வரகு',
 5.0, 8.0, 400, 350, 1500, 18, 35, 'kharif', 100, 'low',
 35.00, 1.5, 4.0,
 ARRAY['sandy_loam', 'loam', 'laterite'],
 ARRAY['Am', 'Aw'],
 'Nutritious millet; tolerates poor soils and acidic pH.',
 'ஊட்டச்சத்து மிகுந்த; அமில மண்ணிலும் வளரும்.'),

-- OILSEEDS
('groundnut', 'Groundnut (Peanut)', 'வேர்க்கடலை',
 5.5, 7.0, 500, 400, 1200, 20, 35, 'kharif', 110, 'low',
 55.00, 1.2, 3.5,
 ARRAY['sandy_loam', 'loam', 'red_laterite'],
 ARRAY['BSh', 'Aw', 'Am'],
 'Popular oilseed; fixes nitrogen; suits well-drained red soils.',
 'நைட்ரஜன் நிலையாக்கும்; நன்கு வடிகட்டிய சிவப்பு மண்ணுக்கு ஏற்றது.'),

('sesame', 'Sesame (Gingelly)', 'எள்',
 5.5, 8.0, 300, 250, 700, 25, 40, 'kharif', 80, 'low',
 120.00, 0.3, 0.9,
 ARRAY['sandy_loam', 'loam'],
 ARRAY['BSh', 'BWh', 'Aw'],
 'Drought-tolerant oilseed with high market price.',
 'வறட்சி தாங்கும் எண்ணெய் வித்து; நல்ல சந்தை விலை.'),

('castor', 'Castor', 'ஆமணக்கு',
 6.0, 8.5, 400, 350, 800, 20, 38, 'kharif', 150, 'medium',
 60.00, 1.0, 2.5,
 ARRAY['sandy_loam', 'loam', 'black_cotton'],
 ARRAY['BSh', 'Aw'],
 'Industrial oilseed; grows on degraded and dryland soils.',
 'தரிசு நிலத்திலும் வளரும் தொழில்துறை எண்ணெய் வித்து.'),

-- PULSES
('blackgram', 'Black Gram (Urad)', 'உளுந்து',
 6.0, 7.5, 300, 250, 900, 25, 38, 'kharif', 70, 'low',
 80.00, 0.6, 1.5,
 ARRAY['loam', 'clay_loam', 'alluvial'],
 ARRAY['Am', 'Aw'],
 'Short-duration pulse; improves soil nitrogen.',
 'குறுகிய கால பயிர்; மண்ணில் நைட்ரஜனை அதிகரிக்கும்.'),

('greengram', 'Green Gram (Moong)', 'பாசிப்பயறு',
 6.0, 7.5, 350, 250, 800, 28, 38, 'kharif', 65, 'low',
 90.00, 0.5, 1.2,
 ARRAY['loam', 'sandy_loam', 'alluvial'],
 ARRAY['Am', 'Aw', 'BSh'],
 'Fast-maturing pulse with good protein content.',
 'விரைவாக முதிரும் புரதச்சத்து நிறைந்த பயிர்.'),

('cowpea', 'Cowpea (Karamani)', 'தட்டைப்பயறு',
 5.5, 8.5, 300, 200, 700, 25, 40, 'kharif', 60, 'low',
 70.00, 0.6, 1.8,
 ARRAY['sandy_loam', 'loam'],
 ARRAY['BSh', 'Aw', 'Am'],
 'Drought-tolerant pulse; good for intercropping.',
 'வறட்சி தாங்கும்; ஊடுபயிராக ஏற்றது.'),

-- CASH CROPS
('sugarcane', 'Sugarcane', 'கரும்பு',
 6.0, 8.0, 1500, 1200, 2000, 20, 38, 'perennial', 360, 'high',
 3.50, 60.0, 120.0,
 ARRAY['loam', 'clay_loam', 'alluvial'],
 ARRAY['Am', 'Aw', 'Cwa'],
 'High-water cash crop; needs irrigation; long duration.',
 'அதிக நீர் தேவை; நீண்ட வளர்ச்சி காலம்; பணப்பயிர்.'),

('cotton', 'Cotton', 'பருத்தி',
 6.0, 8.0, 700, 500, 1200, 21, 38, 'kharif', 180, 'high',
 65.00, 1.0, 2.5,
 ARRAY['black_cotton', 'clay', 'loam'],
 ARRAY['BSh', 'Aw'],
 'Major fiber crop; thrives in black cotton (vertisol) soils.',
 'முக்கிய நார் பயிர்; கரிசல் மண்ணில் சிறப்பாக வளரும்.'),

-- HORTICULTURE
('banana', 'Banana', 'வாழை',
 5.5, 7.5, 1200, 900, 2500, 20, 38, 'perennial', 360, 'high',
 25.00, 20.0, 45.0,
 ARRAY['loam', 'alluvial', 'clay_loam'],
 ARRAY['Am', 'Aw'],
 'High-value fruit; needs well-drained fertile soil and irrigation.',
 'அதிக மதிப்பு பழம்; நல்ல வடிகட்டும் மண்ணும் பாசனமும் தேவை.'),

('turmeric', 'Turmeric (Manjal)', 'மஞ்சள்',
 5.5, 7.5, 1200, 1000, 2000, 20, 35, 'kharif', 270, 'medium',
 130.00, 15.0, 25.0,
 ARRAY['loam', 'clay_loam', 'alluvial'],
 ARRAY['Am', 'Aw'],
 'High-value spice; needs well-distributed rainfall and shade.',
 'அதிக மதிப்பு மசாலா; சீரான மழை மற்றும் நிழல் தேவை.'),

('onion', 'Onion (Vengayam)', 'வெங்காயம்',
 6.0, 7.5, 400, 300, 700, 13, 30, 'rabi', 120, 'medium',
 20.00, 15.0, 30.0,
 ARRAY['sandy_loam', 'loam'],
 ARRAY['BSh', 'Aw'],
 'Short-duration vegetable crop with volatile market price.',
 'குறுகிய கால காய்கறிப் பயிர்; சந்தை விலை ஏற்ற இறக்கம்.'),

('tomato', 'Tomato (Thakkali)', 'தக்காளி',
 5.5, 7.5, 600, 400, 900, 18, 32, 'rabi', 90, 'high',
 30.00, 25.0, 50.0,
 ARRAY['loam', 'sandy_loam', 'alluvial'],
 ARRAY['Am', 'Aw', 'BSh'],
 'Popular vegetable; needs good drainage and consistent irrigation.',
 'பிரபலமான காய்கறி; நல்ல வடிகட்டுதல் மற்றும் நிலையான பாசனம் தேவை.'),

('sunflower', 'Sunflower (Suriyakanthi)', 'சூரியகாந்தி',
 6.0, 8.0, 450, 350, 800, 18, 35, 'rabi', 95, 'medium',
 55.00, 0.9, 2.0,
 ARRAY['loam', 'sandy_loam', 'clay_loam'],
 ARRAY['BSh', 'Aw', 'Cwa'],
 'Versatile oilseed; tolerates mild drought; good rabi crop.',
 'பல்பயன் எண்ணெய் வித்து; மிதமான வறட்சியை தாங்கும்.'),

('tapioca', 'Tapioca (Maravalli)', 'மரவள்ளி கிழங்கு',
 5.0, 8.0, 800, 600, 2000, 20, 38, 'perennial', 270, 'medium',
 8.00, 20.0, 40.0,
 ARRAY['sandy_loam', 'loam', 'laterite'],
 ARRAY['Am', 'Aw'],
 'Starchy root crop; tolerates acidic and laterite soils.',
 'மாவுச்சத்து வேர் பயிர்; அமில மண்ணிலும் வளரும்.')

ON CONFLICT (crop_name) DO UPDATE SET
    market_price_per_kg = EXCLUDED.market_price_per_kg,
    updated_at = NOW();


-- Sample market price entries for trend charts
INSERT INTO market_prices (crop_name, market_name, district, price_per_kg, recorded_date)
VALUES
  ('paddy',     'Thanjavur APMC',  'Thanjavur',  21.50, '2026-08-01'),
  ('paddy',     'Thanjavur APMC',  'Thanjavur',  22.00, '2026-08-10'),
  ('groundnut', 'Tirunelveli APMC','Tirunelveli', 54.00, '2026-08-01'),
  ('groundnut', 'Tirunelveli APMC','Tirunelveli', 57.50, '2026-08-10'),
  ('cotton',    'Coimbatore APMC', 'Coimbatore',  63.00, '2026-08-01'),
  ('cotton',    'Coimbatore APMC', 'Coimbatore',  66.00, '2026-08-10'),
  ('turmeric',  'Erode APMC',      'Erode',      128.00, '2026-08-01'),
  ('turmeric',  'Erode APMC',      'Erode',      133.00, '2026-08-10'),
  ('banana',    'Trichy APMC',     'Trichy',      24.00, '2026-08-01'),
  ('banana',    'Trichy APMC',     'Trichy',      26.00, '2026-08-10')
ON CONFLICT DO NOTHING;
