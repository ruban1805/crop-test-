"""
tests/test_decision_engine.py
==============================
Unit tests for the core decision engine — runnable with NO external APIs.

Run with:   python -m pytest tests/ -v
            (from the crop-dss/ directory)
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from decision_engine.crop_database import CROP_DB, get_crop, list_crops
from decision_engine.decision_matrix import LandProfile, DecisionMatrix, CRITERIA
from decision_engine.decision_matrix import _bell, _score_soil_fit, _score_water_fit
from decision_engine.ahp import compute_ahp_weights, DEFAULT_PAIRWISE, DEFAULT_WEIGHTS
from decision_engine.topsis import run_topsis, topsis_with_details
from decision_engine.heap_ranker import MinHeap, HeapEntry, get_top_k_crops
from decision_engine.trie import Trie, build_crop_trie
from decision_engine.sliding_window import moving_average, analyse_weather_trend, detect_drought_streak
from decision_engine.decision_tree import eliminate_crops
from decision_engine.engine import run_engine


# =============================================================================
# 1. Crop Database (HashMap) tests
# =============================================================================

class TestCropDatabase:
    def test_crop_count(self):
        """DB must have at least 15 Tamil Nadu crops."""
        assert len(CROP_DB) >= 15

    def test_paddy_in_db(self):
        assert "paddy" in CROP_DB

    def test_crop_profile_structure(self):
        """Every crop must have required keys."""
        required = {
            "soil_pH_range", "water_need_mm", "temp_range_C",
            "season", "duration_days", "market_price_per_kg",
            "soil_types", "climate_zones",
            "min_rainfall_mm", "max_rainfall_mm", "yield_range_t_ha",
        }
        for name, profile in CROP_DB.items():
            missing = required - profile.keys()
            assert not missing, f"{name} missing keys: {missing}"

    def test_get_crop_lookup(self):
        """Hash map O(1) lookup returns correct profile."""
        p = get_crop("paddy")
        assert p["season"] == "kharif"
        assert p["soil_pH_range"][0] < p["soil_pH_range"][1]

    def test_get_crop_case_insensitive(self):
        p = get_crop("PADDY")
        assert "soil_pH_range" in p

    def test_get_crop_not_found(self):
        with pytest.raises(KeyError):
            get_crop("avocado")

    def test_list_crops(self):
        crops = list_crops()
        assert len(crops) == len(CROP_DB)
        assert "groundnut" in crops


# =============================================================================
# 2. AHP tests
# =============================================================================

class TestAHP:
    def test_weights_sum_to_one(self):
        weights, cr = compute_ahp_weights(DEFAULT_PAIRWISE)
        assert abs(sum(weights) - 1.0) < 1e-6

    def test_all_weights_positive(self):
        weights, _ = compute_ahp_weights(DEFAULT_PAIRWISE)
        assert all(w > 0 for w in weights)

    def test_consistency_ratio_acceptable(self):
        _, cr = compute_ahp_weights(DEFAULT_PAIRWISE)
        assert cr < 0.10, f"CR={cr} exceeds 0.10 threshold"

    def test_default_weights_length(self):
        assert len(DEFAULT_WEIGHTS) == len(CRITERIA)

    def test_inconsistent_matrix_raises(self):
        # Deliberately inconsistent matrix
        bad = [
            [1, 9, 1/9],
            [1/9, 1, 9],
            [9, 1/9, 1],
        ]
        with pytest.raises(ValueError):
            compute_ahp_weights(bad)

    def test_soil_fit_is_highest_weight(self):
        """Expert judgement: soil_fit should have the highest weight."""
        soil_idx = CRITERIA.index("soil_fit")
        assert DEFAULT_WEIGHTS[soil_idx] == max(DEFAULT_WEIGHTS)


# =============================================================================
# 3. Scoring function tests
# =============================================================================

class TestScoringFunctions:
    def test_bell_inside_range(self):
        assert _bell(6.5, 6.0, 7.0) == 1.0

    def test_bell_at_boundary(self):
        assert _bell(6.0, 6.0, 7.0) == 1.0

    def test_bell_outside_range_decays(self):
        score = _bell(4.0, 6.0, 7.0)
        assert 0.0 <= score < 1.0

    def test_bell_far_outside_zero(self):
        score = _bell(0.0, 6.0, 7.0)
        assert score == 0.0

    def test_soil_fit_perfect_match(self):
        paddy = CROP_DB["paddy"]
        score = _score_soil_fit(6.5, "clay_loam", paddy)
        assert score > 0.8

    def test_soil_fit_wrong_pH(self):
        paddy = CROP_DB["paddy"]
        score = _score_soil_fit(9.0, "clay_loam", paddy)
        assert score < 0.5

    def test_water_fit_rain_fed_adequate(self):
        paddy = CROP_DB["paddy"]
        score = _score_water_fit("rain_fed", 1300, paddy)
        assert score >= 0.8

    def test_water_fit_deficit(self):
        paddy = CROP_DB["paddy"]  # needs 1200 mm
        score = _score_water_fit("rain_fed", 300, paddy)
        assert score < 0.5


# =============================================================================
# 4. Decision Matrix tests
# =============================================================================

class TestDecisionMatrix:
    def _make_land(self):
        return LandProfile(
            latitude=10.8, longitude=78.7,
            soil_pH=6.5, soil_type="loam",
            water_source="rain_fed",
            land_size_ha=2.0,
            avg_temp_C=28.0,
            annual_rainfall_mm=900,
        )

    def test_matrix_dimensions(self):
        land = self._make_land()
        crops = ["paddy", "groundnut", "maize"]
        m = DecisionMatrix()
        m.build_from_profiles(crops, land, {c: CROP_DB[c] for c in crops})
        assert m.n_rows() == 3
        assert m.n_cols() == len(CRITERIA)

    def test_all_scores_in_range(self):
        land = self._make_land()
        crops = list(CROP_DB.keys())
        m = DecisionMatrix()
        m.build_from_profiles(crops, land, CROP_DB)
        for r in range(m.n_rows()):
            for c in range(m.n_cols()):
                val = m.get_cell(r, c)
                assert 0.0 <= val <= 1.0, f"Cell [{r},{c}]={val} out of [0,1]"

    def test_matrix_repr_runs(self):
        land = self._make_land()
        m = DecisionMatrix()
        m.build_from_profiles(["paddy", "maize"], land, CROP_DB)
        repr_str = repr(m)
        assert "paddy" in repr_str


# =============================================================================
# 5. TOPSIS tests
# =============================================================================

class TestTOPSIS:
    def test_closeness_range(self):
        matrix = [
            [0.8, 0.7, 0.9, 0.6, 0.8, 0.7],
            [0.3, 0.4, 0.5, 0.4, 0.3, 0.4],
            [0.6, 0.6, 0.6, 0.5, 0.6, 0.5],
        ]
        weights = [1/6] * 6
        closeness = run_topsis(matrix, weights)
        for c in closeness:
            assert 0.0 <= c <= 1.0

    def test_best_crop_has_highest_closeness(self):
        """Crop with uniformly high scores should be ranked first."""
        matrix = [
            [0.9, 0.9, 0.9, 0.9, 0.9, 0.9],  # clearly best
            [0.1, 0.1, 0.1, 0.1, 0.1, 0.1],  # clearly worst
            [0.5, 0.5, 0.5, 0.5, 0.5, 0.5],  # middle
        ]
        weights = [1/6] * 6
        closeness = run_topsis(matrix, weights)
        assert closeness[0] == max(closeness)

    def test_topsis_with_details_sorted(self):
        matrix = [
            [0.7, 0.6, 0.8, 0.5, 0.7, 0.6],
            [0.4, 0.3, 0.5, 0.4, 0.4, 0.3],
        ]
        crops = ["crop_a", "crop_b"]
        weights = [1/6] * 6
        results = topsis_with_details(matrix, weights, crops, CRITERIA)
        assert results[0]["suitability_percent"] >= results[1]["suitability_percent"]

    def test_topsis_single_crop(self):
        matrix = [[0.7, 0.6, 0.8, 0.5, 0.7, 0.6]]
        results = run_topsis(matrix, [1/6]*6)
        assert len(results) == 1

    def test_topsis_empty_matrix(self):
        assert run_topsis([], [1/6]*6) == []


# =============================================================================
# 6. Heap (Priority Queue) tests
# =============================================================================

class TestMinHeap:
    def test_heap_min_property(self):
        h = MinHeap()
        for score in [5.0, 2.0, 8.0, 1.0, 9.0]:
            h.push(HeapEntry(score=score, crop_name=f"crop_{score}"))
        assert h.peek().score == 1.0

    def test_heap_pop_order(self):
        h = MinHeap()
        scores = [3.0, 1.0, 4.0, 1.5, 2.0]
        for s in scores:
            h.push(HeapEntry(score=s, crop_name=f"c{s}"))
        popped = [h.pop().score for _ in range(len(scores))]
        assert popped == sorted(scores)

    def test_heap_empty_pop_raises(self):
        h = MinHeap()
        with pytest.raises(IndexError):
            h.pop()

    def test_get_top_k(self):
        crops = [
            {"crop_name": f"crop_{i}", "suitability_percent": float(i)}
            for i in range(20)
        ]
        top5 = get_top_k_crops(crops, k=5)
        assert len(top5) == 5
        assert top5[0]["suitability_percent"] == 19.0
        assert top5[4]["suitability_percent"] == 15.0

    def test_get_top_k_less_than_k(self):
        crops = [{"crop_name": "a", "suitability_percent": 80.0}]
        top5 = get_top_k_crops(crops, k=5)
        assert len(top5) == 1

    def test_heap_to_sorted_list(self):
        h = MinHeap()
        for s in [4, 2, 6, 1]:
            h.push(HeapEntry(score=float(s), crop_name=f"c{s}"))
        sorted_entries = h.to_sorted_list()
        scores = [e.score for e in sorted_entries]
        assert scores == sorted(scores, reverse=True)


# =============================================================================
# 7. Trie tests
# =============================================================================

class TestTrie:
    def test_insert_and_search(self):
        t = Trie()
        t.insert("paddy")
        assert t.search("paddy")
        assert not t.search("cotton")

    def test_autocomplete(self):
        t = Trie()
        for word in ["paddy", "pearl_millet", "finger_millet", "maize"]:
            t.insert(word)
        results = t.autocomplete("p")
        assert "paddy" in results
        assert "pearl_millet" in results
        assert "maize" not in results

    def test_autocomplete_no_match(self):
        t = Trie()
        t.insert("paddy")
        assert t.autocomplete("xyz") == []

    def test_starts_with(self):
        t = Trie()
        t.insert("groundnut")
        assert t.starts_with("ground")
        assert not t.starts_with("apple")

    def test_delete(self):
        t = Trie()
        t.insert("paddy")
        t.delete("paddy")
        assert not t.search("paddy")

    def test_len(self):
        t = build_crop_trie(CROP_DB)
        # Each crop inserts its original name + title-case version
        assert len(t) >= len(CROP_DB)

    def test_case_insensitive(self):
        t = Trie()
        t.insert("PADDY")
        assert t.search("paddy")

    def test_build_crop_trie(self):
        t = build_crop_trie(CROP_DB)
        assert t.starts_with("pad")  # paddy


# =============================================================================
# 8. Sliding Window tests
# =============================================================================

class TestSlidingWindow:
    def test_moving_average_length(self):
        data = list(range(30))
        ma = moving_average(data, window=7)
        assert len(ma) == 30 - 7 + 1

    def test_moving_average_values(self):
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        ma = moving_average(data, window=3)
        assert ma[0] == pytest.approx(2.0)  # (1+2+3)/3
        assert ma[1] == pytest.approx(3.0)  # (2+3+4)/3
        assert ma[2] == pytest.approx(4.0)  # (3+4+5)/3

    def test_drought_streak(self):
        rain = [5, 0, 0, 0, 10, 0, 0, 5]
        streak = detect_drought_streak(rain, threshold_mm=2.0)
        assert streak == 3  # three consecutive dry days

    def test_weather_trend_increasing(self):
        data = list(range(1, 31))  # steadily increasing
        trend = analyse_weather_trend(data, window=5)
        assert trend.trend == "increasing"

    def test_weather_trend_decreasing(self):
        data = list(range(30, 0, -1))
        trend = analyse_weather_trend(data, window=5)
        assert trend.trend == "decreasing"

    def test_weather_trend_empty(self):
        t = analyse_weather_trend([])
        assert t.mean == 0

    def test_invalid_window_raises(self):
        with pytest.raises(ValueError):
            moving_average([1, 2, 3], window=10)


# =============================================================================
# 9. Decision Tree elimination tests
# =============================================================================

class TestDecisionTree:
    def _make_land(self, **kwargs):
        defaults = dict(
            latitude=10.8, longitude=78.7,
            soil_pH=6.5, soil_type="loam",
            water_source="rain_fed",
            land_size_ha=2.0,
            avg_temp_C=28.0,
            annual_rainfall_mm=900,
        )
        defaults.update(kwargs)
        return LandProfile(**defaults)

    def test_paddy_passes_normal_conditions(self):
        land = self._make_land(soil_pH=6.5, avg_temp_C=28, annual_rainfall_mm=1200)
        kept, eliminated = eliminate_crops(CROP_DB, land)
        assert "paddy" in kept

    def test_extreme_pH_eliminates_crops(self):
        # pH 9.5 is outside tolerance for most crops
        land = self._make_land(soil_pH=9.5)
        kept, _ = eliminate_crops(CROP_DB, land)
        assert len(kept) < len(CROP_DB)

    def test_extreme_cold_eliminates_crops(self):
        # 5°C is below ALL Tamil Nadu crop minimums
        land = self._make_land(avg_temp_C=5.0)
        kept, _ = eliminate_crops(CROP_DB, land)
        assert len(kept) == 0

    def test_drought_eliminates_high_water_crops(self):
        # Only 100 mm rainfall, rain-fed → paddy (1200mm) should be eliminated
        land = self._make_land(
            annual_rainfall_mm=100, water_source="rain_fed"
        )
        kept, eliminated = eliminate_crops(CROP_DB, land)
        elim_names = [e["crop"] for e in eliminated]
        assert "paddy" in elim_names

    def test_irrigated_keeps_high_water_crops(self):
        # With irrigation, paddy can still be considered
        land = self._make_land(
            annual_rainfall_mm=100, water_source="irrigated"
        )
        kept, _ = eliminate_crops(CROP_DB, land)
        assert "paddy" in kept


# =============================================================================
# 10. Full engine integration tests
# =============================================================================

class TestEngine:
    def _make_land(self, **kwargs):
        defaults = dict(
            latitude=10.8, longitude=78.7,
            soil_pH=6.5, soil_type="loam",
            water_source="rain_fed",
            land_size_ha=2.0,
            avg_temp_C=28.0,
            annual_rainfall_mm=900,
        )
        defaults.update(kwargs)
        return LandProfile(**defaults)

    def test_engine_returns_recommendations(self):
        land = self._make_land()
        result = run_engine(land, top_k=5)
        recs = result["recommendations"]
        assert len(recs) > 0

    def test_engine_top_k_respected(self):
        land = self._make_land()
        result = run_engine(land, top_k=3)
        assert len(result["recommendations"]) <= 3

    def test_recommendations_have_required_fields(self):
        land = self._make_land()
        result = run_engine(land, top_k=5)
        for rec in result["recommendations"]:
            assert rec.suitability_percent >= 0
            assert rec.suitability_percent <= 100
            assert rec.crop_name in CROP_DB
            assert len(rec.top_reasons) > 0
            assert rec.expected_yield_range != ""
            assert rec.best_sowing_window != ""

    def test_recommendations_sorted_descending(self):
        land = self._make_land()
        result = run_engine(land, top_k=5)
        pcts = [r.suitability_percent for r in result["recommendations"]]
        assert pcts == sorted(pcts, reverse=True)

    def test_engine_ranks_start_at_one(self):
        land = self._make_land()
        result = run_engine(land)
        recs = result["recommendations"]
        assert recs[0].rank == 1

    def test_engine_dry_land_prefers_drought_tolerant(self):
        land = self._make_land(
            annual_rainfall_mm=350,
            avg_temp_C=35,
            soil_pH=7.0,
            soil_type="sandy_loam",
        )
        result = run_engine(land, top_k=3)
        recs = result["recommendations"]
        top_names = [r.crop_name for r in recs]
        # Drought-tolerant crops should dominate
        drought_tolerant = {"pearl_millet", "sorghum", "sesame", "cowpea", "finger_millet", "castor"}
        overlap = set(top_names) & drought_tolerant
        assert len(overlap) >= 1, f"Expected drought-tolerant crops, got {top_names}"

    def test_engine_wet_land_includes_paddy(self):
        land = self._make_land(
            annual_rainfall_mm=1500,
            soil_pH=6.0,
            soil_type="clay_loam",
            water_source="irrigated",
        )
        result = run_engine(land, top_k=5)
        top_names = [r.crop_name for r in result["recommendations"]]
        assert "paddy" in top_names, f"Paddy not in recommendations: {top_names}"

    def test_engine_tamil_language(self):
        land = self._make_land()
        result = run_engine(land, top_k=3, lang="ta")
        for rec in result["recommendations"]:
            # Tamil reasons should contain Tamil Unicode characters
            all_text = " ".join(rec.top_reasons)
            # At least some recommendations should have Tamil text
            # (pH condition might produce English for pure numeric facts)
            assert len(rec.top_reasons) > 0

    def test_engine_ml_blend(self):
        land = self._make_land()
        # Inject mock ML scores
        ml_scores = {name: 0.7 for name in CROP_DB.keys()}
        result = run_engine(land, top_k=3, ml_scores=ml_scores, ml_blend_weight=0.4)
        for rec in result["recommendations"]:
            assert rec.ml_blend_applied is True

    def test_ahp_weights_in_result(self):
        land = self._make_land()
        result = run_engine(land)
        assert "ahp_weights" in result
        assert abs(sum(result["ahp_weights"].values()) - 1.0) < 1e-5

    def test_engine_total_elimination_returns_error(self):
        # Impossible conditions — pH 11 and 3°C temperature
        land = self._make_land(soil_pH=11.0, avg_temp_C=3.0)
        result = run_engine(land)
        assert len(result["recommendations"]) == 0


# =============================================================================
# Main — run tests directly with `python test_decision_engine.py`
# =============================================================================

if __name__ == "__main__":
    import subprocess
    subprocess.run(["python", "-m", "pytest", __file__, "-v"])
