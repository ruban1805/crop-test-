"""
trie.py
=======
DATA STRUCTURE: Trie (Prefix Tree)
WHY: Crop name autocomplete/search in the UI requires O(L) lookup
     (L = length of prefix query), regardless of how many crops are
     in the database. A hash-map prefix scan would be O(n·L); a Trie
     reduces this to O(L + output_size).

     Each TrieNode stores one character and a dict of children (itself
     a hash map internally, but the tree topology is the Trie structure).

Usage: insert all crop names at startup, then query with prefixes from
the mobile app's search bar.
"""

from __future__ import annotations
from typing import Dict, List, Optional


class TrieNode:
    """
    A single node in the Trie.
    children : dict mapping char → TrieNode  (hash map per level)
    is_end   : marks a complete word terminating at this node
    full_word: stores the complete crop name at terminal nodes
    """

    def __init__(self) -> None:
        self.children: Dict[str, "TrieNode"] = {}
        self.is_end: bool = False
        self.full_word: Optional[str] = None


class Trie:
    """
    Prefix tree for crop name autocomplete.

    All operations are case-insensitive and normalise spaces → underscores.
    """

    def __init__(self) -> None:
        self.root = TrieNode()
        self._count = 0

    def _normalise(self, word: str) -> str:
        return word.lower().replace(" ", "_")

    # ── Insertion ── O(L) where L = word length ─────────────────────────

    def insert(self, word: str) -> None:
        """Insert a crop name into the trie."""
        key = self._normalise(word)
        node = self.root
        for char in key:
            if char not in node.children:
                node.children[char] = TrieNode()
            node = node.children[char]
        if not node.is_end:
            node.is_end = True
            node.full_word = word  # preserve original formatting
            self._count += 1

    # ── Search ── O(L) ───────────────────────────────────────────────────

    def search(self, word: str) -> bool:
        """Return True if exact word is in the trie."""
        node = self._find_node(self._normalise(word))
        return node is not None and node.is_end

    def starts_with(self, prefix: str) -> bool:
        """Return True if any word starts with prefix."""
        return self._find_node(self._normalise(prefix)) is not None

    # ── Autocomplete ── O(L + output) ────────────────────────────────────

    def autocomplete(self, prefix: str, max_results: int = 10) -> List[str]:
        """
        Return all crop names starting with prefix.
        Performs DFS from the prefix terminal node.
        """
        key = self._normalise(prefix)
        node = self._find_node(key)
        if node is None:
            return []

        results: List[str] = []
        self._dfs_collect(node, results, max_results)
        return results

    # ── Delete ── O(L) ───────────────────────────────────────────────────

    def delete(self, word: str) -> bool:
        """Remove a word from the trie. Returns True if it existed."""
        key = self._normalise(word)
        return self._delete_recursive(self.root, key, 0)

    def _delete_recursive(self, node: TrieNode, key: str, depth: int) -> bool:
        if depth == len(key):
            if not node.is_end:
                return False  # word not found
            node.is_end = False
            node.full_word = None
            self._count -= 1
            return len(node.children) == 0  # True → caller can delete this node
        char = key[depth]
        if char not in node.children:
            return False
        should_delete_child = self._delete_recursive(node.children[char], key, depth + 1)
        if should_delete_child:
            del node.children[char]
            return not node.is_end and len(node.children) == 0
        return False

    # ── Helpers ──────────────────────────────────────────────────────────

    def _find_node(self, key: str) -> Optional[TrieNode]:
        """Traverse to the node at end of key; return None if not found."""
        node = self.root
        for char in key:
            if char not in node.children:
                return None
            node = node.children[char]
        return node

    def _dfs_collect(
        self,
        node: TrieNode,
        results: List[str],
        max_results: int,
    ) -> None:
        """DFS to collect all complete words reachable from node."""
        if len(results) >= max_results:
            return
        if node.is_end and node.full_word:
            results.append(node.full_word)
        for child in node.children.values():
            if len(results) >= max_results:
                return
            self._dfs_collect(child, results, max_results)

    def __len__(self) -> int:
        return self._count

    def __repr__(self) -> str:
        return f"Trie({self._count} words)"


# ---------------------------------------------------------------------------
# Factory: build a trie pre-loaded with the crop database
# ---------------------------------------------------------------------------

def build_crop_trie(crop_db: dict) -> Trie:
    """Build a Trie pre-loaded with all crop names from the crop database."""
    trie = Trie()
    for crop_name in crop_db.keys():
        # Insert both underscore form and display form
        trie.insert(crop_name)
        display = crop_name.replace("_", " ").title()
        trie.insert(display)
    return trie
