"""
sliding_window.py
=================
DATA STRUCTURE: Sliding Window over Array
WHY: Weather trend analysis over 14–90 day windows is a classic sliding
     window problem — we maintain a running sum and update in O(1) per
     step instead of recomputing sums from scratch each time (O(n·w) naïve
     vs O(n) with sliding window).

Use cases in this app:
  - Moving average of daily rainfall over last N days
  - Moving average of daily temperature
  - Detecting drought streaks (consecutive days < threshold)
  - Detecting excessive-rain windows (waterlogging risk)
"""

from __future__ import annotations
from typing import List, Optional, Tuple
from dataclasses import dataclass


@dataclass
class WeatherTrend:
    """Summary of a sliding-window trend analysis."""
    window_days: int
    mean: float
    min_val: float
    max_val: float
    trend: str        # 'increasing' | 'decreasing' | 'stable'
    drought_days: int  # consecutive days below threshold
    excess_days: int   # consecutive days above upper threshold
    values: List[float]


def moving_average(
    data: List[float],
    window: int,
) -> List[float]:
    """
    Compute moving average using explicit sliding window.
    Time complexity: O(n), Space: O(n)

    Algorithm:
      - Maintain running_sum
      - Add new element, subtract element leaving the window
      - Each step: O(1)
    """
    if window <= 0 or window > len(data):
        raise ValueError(f"Window size {window} invalid for data length {len(data)}")

    averages: List[float] = []
    running_sum = sum(data[:window])
    averages.append(running_sum / window)

    for i in range(window, len(data)):
        running_sum += data[i]           # add incoming element
        running_sum -= data[i - window]  # subtract outgoing element
        averages.append(running_sum / window)

    return averages


def detect_drought_streak(
    daily_rainfall: List[float],
    threshold_mm: float = 2.0,
) -> int:
    """
    Return the longest consecutive run of days with rainfall < threshold.
    Sliding window of variable length — O(n).
    """
    max_streak = 0
    current_streak = 0
    for rain in daily_rainfall:
        if rain < threshold_mm:
            current_streak += 1
            max_streak = max(max_streak, current_streak)
        else:
            current_streak = 0
    return max_streak


def detect_excess_rain_window(
    daily_rainfall: List[float],
    threshold_mm: float = 30.0,
    window: int = 7,
) -> Tuple[int, float]:
    """
    Find the maximum total rainfall over any window-day period.
    Returns (start_day_index, max_total_rainfall).
    """
    if len(daily_rainfall) < window:
        return 0, sum(daily_rainfall)

    window_sum = sum(daily_rainfall[:window])
    max_sum = window_sum
    max_start = 0

    for i in range(window, len(daily_rainfall)):
        window_sum += daily_rainfall[i]
        window_sum -= daily_rainfall[i - window]
        if window_sum > max_sum:
            max_sum = window_sum
            max_start = i - window + 1

    return max_start, max_sum


def analyse_weather_trend(
    daily_values: List[float],
    window: int = 14,
    drought_threshold: float = 2.0,
    excess_threshold: float = 30.0,
) -> WeatherTrend:
    """
    Full trend analysis on a time series (rainfall or temperature).

    Parameters
    ----------
    daily_values      : list of daily measurements
    window            : moving average window size in days
    drought_threshold : daily value below which is considered drought
    excess_threshold  : daily value above which is considered excess

    Returns
    -------
    WeatherTrend summary dataclass
    """
    if not daily_values:
        return WeatherTrend(
            window_days=window, mean=0, min_val=0, max_val=0,
            trend="stable", drought_days=0, excess_days=0, values=[]
        )

    ma = moving_average(daily_values, min(window, len(daily_values)))
    mean_val = sum(daily_values) / len(daily_values)

    # Trend detection: compare first half mean vs second half mean
    mid = len(ma) // 2
    if mid > 0:
        first_half_mean = sum(ma[:mid]) / mid
        second_half_mean = sum(ma[mid:]) / max(len(ma) - mid, 1)
        delta = second_half_mean - first_half_mean
        if delta > 0.5:
            trend = "increasing"
        elif delta < -0.5:
            trend = "decreasing"
        else:
            trend = "stable"
    else:
        trend = "stable"

    drought_days = detect_drought_streak(daily_values, drought_threshold)
    _, max_excess = detect_excess_rain_window(daily_values, excess_threshold, window)
    excess_days = sum(1 for v in daily_values if v > excess_threshold)

    return WeatherTrend(
        window_days=window,
        mean=round(mean_val, 2),
        min_val=round(min(daily_values), 2),
        max_val=round(max(daily_values), 2),
        trend=trend,
        drought_days=drought_days,
        excess_days=excess_days,
        values=ma,
    )


def compute_forecast_rainfall(
    daily_forecast: List[float],
    days: int = 60,
) -> float:
    """
    Sum forecast rainfall over next `days` using a cumulative sliding window.
    Returns total expected rainfall in mm over the period.
    """
    window_data = daily_forecast[:days]
    return sum(window_data)
