"""
topsis.py
=========
TOPSIS — Technique for Order of Preference by Similarity to Ideal Solution.

DATA STRUCTURE: 2D Matrix (list-of-lists) + 1-D arrays (lists)
WHY: TOPSIS is inherently a matrix algorithm (column normalisation,
     weighted matrix, ideal/anti-ideal vector distances). Using explicit
     list-of-lists makes every mathematical step visible for DSA review.

Algorithm steps (Hwang & Yoon, 1981):
  1. Normalise the decision matrix (Euclidean column normalisation)
  2. Multiply by AHP weights → weighted normalised matrix
  3. Identify Positive Ideal Solution (PIS) and Negative Ideal Solution (NIS)
  4. Compute Euclidean distances to PIS and NIS for each crop
  5. Compute closeness coefficient Ci = d_minus / (d_plus + d_minus)
     → Ci ∈ [0, 1] → multiply by 100 = suitability %

Reference: Hwang, C.L.; Yoon, K. (1981). Multiple Attribute Decision Making.
"""

from __future__ import annotations
import math
from typing import List, Tuple, Dict


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run_topsis(
    matrix: List[List[float]],
    weights: List[float],
    benefit_criteria: List[bool] | None = None,
) -> List[float]:
    """
    Run TOPSIS on a decision matrix.

    Parameters
    ----------
    matrix   : 2-D list [n_crops × n_criteria], values in [0, 1]
    weights  : list of n_criteria weights (must sum ≈ 1.0)
    benefit_criteria : list of booleans — True if higher score is better.
                       Defaults to all True (all criteria are benefit type
                       in our normalised score representation).

    Returns
    -------
    closeness : list of floats in [0, 1] — one per crop row.
                Multiply by 100 to get suitability %.
    """
    n_rows = len(matrix)
    if n_rows == 0:
        return []
    n_cols = len(matrix[0])

    if benefit_criteria is None:
        benefit_criteria = [True] * n_cols

    # ── Step 1: Euclidean column normalisation ───────────────────────────
    # r_ij = x_ij / sqrt(sum_k(x_kj^2))
    col_norms: List[float] = []
    for j in range(n_cols):
        sq_sum = sum(matrix[i][j] ** 2 for i in range(n_rows))
        col_norms.append(math.sqrt(sq_sum) if sq_sum > 0 else 1.0)

    normalised: List[List[float]] = [
        [matrix[i][j] / col_norms[j] for j in range(n_cols)]
        for i in range(n_rows)
    ]

    # ── Step 2: Weighted normalised matrix ──────────────────────────────
    # v_ij = w_j * r_ij
    weighted: List[List[float]] = [
        [weights[j] * normalised[i][j] for j in range(n_cols)]
        for i in range(n_rows)
    ]

    # ── Step 3: Positive Ideal Solution (PIS) & Negative Ideal (NIS) ────
    pis: List[float] = []
    nis: List[float] = []
    for j in range(n_cols):
        col_vals = [weighted[i][j] for i in range(n_rows)]
        if benefit_criteria[j]:
            pis.append(max(col_vals))
            nis.append(min(col_vals))
        else:  # cost criterion
            pis.append(min(col_vals))
            nis.append(max(col_vals))

    # ── Step 4: Euclidean distances ──────────────────────────────────────
    d_plus: List[float] = []   # distance to PIS
    d_minus: List[float] = []  # distance to NIS
    for i in range(n_rows):
        dp = math.sqrt(sum((weighted[i][j] - pis[j]) ** 2 for j in range(n_cols)))
        dn = math.sqrt(sum((weighted[i][j] - nis[j]) ** 2 for j in range(n_cols)))
        d_plus.append(dp)
        d_minus.append(dn)

    # ── Step 5: Closeness coefficient ───────────────────────────────────
    closeness: List[float] = []
    for i in range(n_rows):
        denom = d_plus[i] + d_minus[i]
        ci = d_minus[i] / denom if denom > 0 else 0.0
        closeness.append(ci)

    return closeness


def topsis_with_details(
    matrix: List[List[float]],
    weights: List[float],
    crop_names: List[str],
    criteria_names: List[str],
    benefit_criteria: List[bool] | None = None,
) -> List[Dict]:
    """
    Extended TOPSIS that also returns per-criterion contribution details.
    Used for generating the 'top_reasons' explanation shown to farmers.

    Returns
    -------
    list of dicts sorted by closeness descending:
    {
        "crop_name": str,
        "closeness": float,          # 0-1
        "suitability_percent": float,# 0-100
        "d_plus": float,
        "d_minus": float,
        "weighted_scores": dict,     # criterion → weighted score
        "best_criteria": list,       # top 2-3 criteria (highest contrib)
        "worst_criteria": list,      # bottom 1-2 criteria
    }
    """
    n_rows = len(matrix)
    n_cols = len(matrix[0])
    if benefit_criteria is None:
        benefit_criteria = [True] * n_cols

    # Repeat normalisation + weighting (DRY violation intentional for transparency)
    col_norms = []
    for j in range(n_cols):
        sq_sum = sum(matrix[i][j] ** 2 for i in range(n_rows))
        col_norms.append(math.sqrt(sq_sum) if sq_sum > 0 else 1.0)

    normalised = [
        [matrix[i][j] / col_norms[j] for j in range(n_cols)]
        for i in range(n_rows)
    ]
    weighted = [
        [weights[j] * normalised[i][j] for j in range(n_cols)]
        for i in range(n_rows)
    ]

    pis, nis = [], []
    for j in range(n_cols):
        col_vals = [weighted[i][j] for i in range(n_rows)]
        if benefit_criteria[j]:
            pis.append(max(col_vals)); nis.append(min(col_vals))
        else:
            pis.append(min(col_vals)); nis.append(max(col_vals))

    results = []
    all_d_plus, all_d_minus = [], []
    for i in range(n_rows):
        dp = math.sqrt(sum((weighted[i][j] - pis[j]) ** 2 for j in range(n_cols)))
        dn = math.sqrt(sum((weighted[i][j] - nis[j]) ** 2 for j in range(n_cols)))
        all_d_plus.append(dp)
        all_d_minus.append(dn)

    for i in range(n_rows):
        denom = all_d_plus[i] + all_d_minus[i]
        ci = all_d_minus[i] / denom if denom > 0 else 0.0

        weighted_scores = {
            criteria_names[j]: round(weighted[i][j], 4)
            for j in range(n_cols)
        }

        # Rank criteria by weighted score for explanation
        sorted_criteria = sorted(
            weighted_scores.items(), key=lambda x: x[1], reverse=True
        )

        results.append({
            "crop_name": crop_names[i],
            "closeness": ci,
            "suitability_percent": round(ci * 100, 2),
            "d_plus": round(all_d_plus[i], 6),
            "d_minus": round(all_d_minus[i], 6),
            "weighted_scores": weighted_scores,
            "best_criteria": [c for c, _ in sorted_criteria[:3]],
            "worst_criteria": [c for c, _ in sorted_criteria[-2:]],
        })

    results.sort(key=lambda x: x["closeness"], reverse=True)
    return results
