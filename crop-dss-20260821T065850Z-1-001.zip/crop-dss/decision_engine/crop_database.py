"""
crop_database.py
================
DATA STRUCTURE: Hash Map  (Python dict — O(1) average lookup)
WHY: Constant-time retrieval of any crop's agronomic profile by name key.

80+ crops across all categories:
  Cereals · Millets · Pulses · Oilseeds · Cash crops ·
  Vegetables · Fruits · Flowers · Spices · Plantation · Root crops
"""

from typing import Dict, Any

CropProfile = Dict[str, Any]
CropDB = Dict[str, CropProfile]

def _c(soil_pH, water, temp, season, days, price,
       soils, zones, nitrogen, rain_min, rain_max,
       yield_lo, yield_hi, en, ta, category="other"):
    """Helper to build a crop profile dict concisely."""
    return {
        "soil_pH_range": soil_pH,
        "water_need_mm": water,
        "temp_range_C": temp,
        "season": season,
        "duration_days": days,
        "market_price_per_kg": price,
        "soil_types": soils,
        "climate_zones": zones,
        "nitrogen_need": nitrogen,
        "min_rainfall_mm": rain_min,
        "max_rainfall_mm": rain_max,
        "yield_range_t_ha": (yield_lo, yield_hi),
        "description_en": en,
        "description_ta": ta,
        "category": category,
    }


def build_crop_db() -> CropDB:
    crop_db: CropDB = {

        # ══════════════════════════════════════════════════════
        # CEREALS & MILLETS
        # ══════════════════════════════════════════════════════
        "paddy": _c(
            (5.5,7.0), 1200, (20,38), "kharif", 120, 21.0,
            ["clay","clay_loam","loam"], ["Am","Aw","Cwa"],
            "high", 900, 2500, 2.0, 6.0,
            "Staple cereal; needs flooded or waterlogged conditions.",
            "நெல் – தமிழ்நாட்டின் முக்கிய தானியம்; நீர் தேங்கும் நிலம் தேவை.",
            "cereal"),

        "maize": _c(
            (5.8,7.5), 500, (18,35), "kharif", 90, 18.0,
            ["loam","sandy_loam","clay_loam"], ["Am","Aw","BSh","Cwa"],
            "high", 400, 900, 3.0, 8.0,
            "Versatile cereal; used as food, feed, and industrial starch.",
            "மக்காச்சோளம் – உணவு, தீவனம் மற்றும் தொழில்துறைக்கு பயன்படுகிறது.",
            "cereal"),

        "sorghum": _c(
            (5.5,8.5), 350, (25,40), "kharif", 100, 22.0,
            ["loam","sandy_loam","vertisol"], ["BSh","BWh","Aw"],
            "medium", 300, 750, 1.5, 4.5,
            "Drought-tolerant cereal; ideal for dryland farming.",
            "சோளம் – வறட்சி தாங்கும் தானியம்.",
            "cereal"),

        "pearl_millet": _c(
            (5.5,8.0), 300, (25,42), "kharif", 75, 23.0,
            ["sandy_loam","loam"], ["BSh","BWh"],
            "medium", 250, 600, 1.0, 3.5,
            "Heat and drought tolerant millet; short-cycle crop.",
            "கம்பு – வெப்பம் மற்றும் வறட்சியை தாங்கும் குறுகிய கால பயிர்.",
            "cereal"),

        "finger_millet": _c(
            (5.0,8.0), 400, (18,35), "kharif", 100, 35.0,
            ["sandy_loam","loam","laterite"], ["Am","Aw"],
            "low", 350, 1500, 1.5, 4.0,
            "Nutritious millet; tolerates poor soils and acidic pH.",
            "கேழ்வரகு – ஊட்டச்சத்து மிகுந்த; அமில மண்ணிலும் வளரும்.",
            "cereal"),

        "little_millet": _c(
            (5.0,7.5), 300, (20,38), "kharif", 85, 40.0,
            ["sandy_loam","loam","laterite"], ["BSh","Aw"],
            "low", 250, 900, 0.8, 2.0,
            "Minor millet; highly nutritious, grows on poor soils.",
            "சாமை – சிறு தானியம்; ஊட்டச்சத்து மிகுந்தது.",
            "cereal"),

        "foxtail_millet": _c(
            (5.5,7.5), 280, (18,35), "kharif", 75, 42.0,
            ["sandy_loam","loam"], ["BSh","Aw"],
            "low", 220, 700, 0.8, 2.2,
            "Fast-growing millet; drought tolerant with good nutrition.",
            "தினை – விரைவாக வளரும்; வறட்சி தாங்கும் சிறு தானியம்.",
            "cereal"),

        "kodo_millet": _c(
            (5.0,7.5), 280, (20,35), "kharif", 90, 38.0,
            ["sandy_loam","loam","laterite"], ["BSh","Aw"],
            "low", 200, 800, 0.6, 1.8,
            "Hardy millet; grows in dry and poor soil conditions.",
            "வரகு – கடினமான சிறு தானியம்; ஏழை மண்ணிலும் வளரும்.",
            "cereal"),

        "barnyard_millet": _c(
            (5.0,7.5), 300, (18,33), "kharif", 60, 45.0,
            ["sandy_loam","loam"], ["Am","Aw"],
            "low", 250, 1000, 0.7, 2.0,
            "Short-duration nutritious millet; good for fasting foods.",
            "குதிரைவாலி – குறுகிய கால ஊட்டச்சத்து தானியம்.",
            "cereal"),

        "wheat": _c(
            (6.0,7.5), 450, (10,25), "rabi", 120, 22.0,
            ["loam","clay_loam","alluvial"], ["Cwa","BSk"],
            "high", 350, 750, 2.5, 5.5,
            "Cool-season staple cereal; needs cold winters.",
            "கோதுமை – குளிர் பருவ முக்கிய தானியம்.",
            "cereal"),

        "barley": _c(
            (6.0,8.0), 350, (8,22), "rabi", 100, 18.0,
            ["loam","sandy_loam","alluvial"], ["BSk","Cwa"],
            "medium", 280, 650, 1.5, 3.5,
            "Cold tolerant cereal; used for malting and animal feed.",
            "வாற்கோதுமை – குளிர் தாங்கும் தானியம்; மதுவிற்கும் தீவனத்திற்கும்.",
            "cereal"),

