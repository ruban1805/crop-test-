"""
engine.py
=========
Main orchestrator for the Crop Decision Support pipeline.

Pipeline:
  1. Input: LandProfile
  2. Decision Tree elimination → candidate crops list
  3. Build 2D decision matrix for candidates
  4. AHP weights (precomputed or from config)
  5. TOPSIS scoring → closeness coefficients
  6. (Optional) Blend with ML yield score
  7. Min-Heap ranking → top-N crops
  8. Generate human-readable reasons per crop
  9. Return ranked RecommendationResult list
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any

from decision_engine.crop_database import CROP_DB
from decision_engine.decision_matrix import LandProfile, DecisionMatrix, CRITERIA
from decision_engine.decision_tree import eliminate_crops
from decision_engine.ahp import DEFAULT_WEIGHTS, compute_ahp_weights
from decision_engine.topsis import topsis_with_details
from decision_engine.heap_ranker import get_top_k_crops
from decision_engine.sliding_window import analyse_weather_trend, compute_forecast_rainfall


# ---------------------------------------------------------------------------
# Output data structures
# ---------------------------------------------------------------------------

@dataclass
class RecommendationResult:
    """
    Final output for one crop recommendation shown to the farmer.
    This exact structure is serialised as JSON by the FastAPI endpoint.
    """
    rank: int
    crop_name: str
    suitability_percent: float
    top_reasons: List[str]
    worst_factors: List[str]
    expected_yield_range: str         # e.g. "2.0 – 6.0 t/ha"
    best_sowing_window: str           # e.g. "June – July (Kharif)"
    market_price_per_kg: float
    season: str
    duration_days: int
    # Full TOPSIS breakdown for the detail screen
    topsis_scores: Dict[str, float] = field(default_factory=dict)
    # Whether ML yield blend was applied
    ml_blend_applied: bool = False
    ml_yield_score: Optional[float] = None


# ---------------------------------------------------------------------------
# Reason generation
# ---------------------------------------------------------------------------

_CRITERION_LABELS = {
    "soil_fit":       "Soil compatibility",
    "water_fit":      "Water availability",
    "temp_fit":       "Temperature suitability",
    "rainfall_fit":   "Rainfall adequacy",
    "market_demand":  "Market price attractiveness",
    "expected_yield": "Expected yield potential",
}

_CRITERION_TAMIL = {
    "soil_fit":       "மண் பொருத்தம்",
    "water_fit":      "நீர் கிடைக்கும் தன்மை",
    "temp_fit":       "வெப்பநிலை ஏற்புடைமை",
    "rainfall_fit":   "மழை போதுமானது",
    "market_demand":  "சந்தை விலை கவர்ச்சி",
    "expected_yield": "எதிர்பார்க்கப்படும் மகசூல்",
}


def _generate_reasons(
    crop_name: str,
    topsis_detail: Dict,
    land: LandProfile,
    crop_profile: Dict,
    lang: str = "en",
) -> List[str]:
    """
    Generate 2–3 plain-language reason strings explaining the recommendation.
    """
    reasons = []
    labels = _CRITERION_LABELS if lang == "en" else _CRITERION_TAMIL

    # Reason 1: Best contributing criterion
    best = topsis_detail.get("best_criteria", [])
    if best:
        top_crit = best[0]
        score = topsis_detail["weighted_scores"].get(top_crit, 0)
        if lang == "en":
            reasons.append(
                f"{labels.get(top_crit, top_crit)} is strong "
                f"(weighted score: {score:.3f})."
            )
        else:
            reasons.append(
                f"{labels.get(top_crit, top_crit)} வலிமையாக உள்ளது "
                f"(எடை மதிப்பெண்: {score:.3f})."
            )

    # Reason 2: Soil pH specific
    ph_lo, ph_hi = crop_profile["soil_pH_range"]
    if ph_lo <= land.soil_pH <= ph_hi:
        if lang == "en":
            reasons.append(
                f"Your soil pH ({land.soil_pH}) is ideal for {crop_name.replace('_',' ').title()} "
                f"(optimal range {ph_lo}–{ph_hi})."
            )
        else:
            reasons.append(
                f"உங்கள் மண் pH ({land.soil_pH}) இந்த பயிருக்கு ஏற்றது "
                f"(சிறந்த வரம்பு {ph_lo}–{ph_hi})."
            )

    # Reason 3: Rainfall vs crop water need
    rainfall = land.annual_rainfall_mm
    water_need = crop_profile["water_need_mm"]
    ratio = rainfall / water_need if water_need > 0 else 1.0
    if ratio >= 0.9 and lang == "en":
        reasons.append(
            f"Forecast rainfall ({rainfall:.0f} mm) covers "
            f"{ratio*100:.0f}% of crop water requirement ({water_need} mm)."
        )
    elif ratio >= 0.9 and lang == "ta":
        reasons.append(
            f"மழை அளவு ({rainfall:.0f} மிமீ) பயிர் நீர் தேவையின் "
            f"{ratio*100:.0f}% ஐ பூர்த்தி செய்கிறது ({water_need} மிமீ)."
        )
    elif ratio < 0.6 and lang == "en":
        reasons.append(
            f"⚠️ Rainfall ({rainfall:.0f} mm) only covers {ratio*100:.0f}% "
            f"of water need; irrigation is recommended."
        )

    return reasons[:3]  # max 3 reasons


def _generate_worst_factors(
    topsis_detail: Dict,
    lang: str = "en",
) -> List[str]:
    labels = _CRITERION_LABELS if lang == "en" else _CRITERION_TAMIL
    worst = topsis_detail.get("worst_criteria", [])
    return [labels.get(c, c) for c in worst[:2]]


def _sowing_window(season: str) -> str:
    windows = {
        "kharif":    "June – July (Kharif / SW Monsoon)",
        "rabi":      "October – November (Rabi / NE Monsoon)",
        "zaid":      "February – March (Summer / Zaid)",
        "perennial": "Year-round (irrigated); ideally June – July",
    }
    return windows.get(season, "Consult local agricultural extension officer")


# ---------------------------------------------------------------------------
# Main engine function
# ---------------------------------------------------------------------------

def run_engine(
    land: LandProfile,
    top_k: int = 5,
    ahp_config: Optional[Dict] = None,
    ml_scores: Optional[Dict[str, float]] = None,  # crop_name → 0-1 score
    ml_blend_weight: float = 0.4,
    lang: str = "en",
    verbose: bool = False,
) -> Dict[str, Any]:
    """
    Run the full MCDM pipeline and return ranked recommendations.

    Parameters
    ----------
    land            : LandProfile with all agronomic inputs
    top_k           : number of top crops to return
    ahp_config      : optional dict with 'pairwise' key to override weights
    ml_scores       : optional dict of ML yield scores per crop (0-1)
    ml_blend_weight : fraction of ML score in final blend (0 = pure TOPSIS)
    lang            : 'en' | 'ta' — language for reason text
    verbose         : print elimination/scoring info

    Returns
    -------
    {
        "recommendations": List[RecommendationResult],
        "eliminated": List[{"crop": str, "reason": str}],
        "ahp_weights": Dict[str, float],
        "ahp_cr": float,
        "n_candidates": int,
    }
    """

    # ── Step 1: Decision Tree hard elimination ───────────────────────────
    candidate_names, eliminated = eliminate_crops(CROP_DB, land, verbose=verbose)

    if verbose:
        print(f"\n[Engine] {len(candidate_names)} crops passed elimination, "
              f"{len(eliminated)} eliminated.")

    if not candidate_names:
        return {
            "recommendations": [],
            "eliminated": eliminated,
            "ahp_weights": {},
            "ahp_cr": 0.0,
            "n_candidates": 0,
            "error": "All crops were eliminated by hard constraints. "
                     "Please verify land profile inputs.",
        }

    # ── Step 2: Build decision matrix ───────────────────────────────────
    matrix_obj = DecisionMatrix(criteria=CRITERIA)
    candidate_db = {k: CROP_DB[k] for k in candidate_names}
    matrix_obj.build_from_profiles(candidate_names, land, candidate_db)

    raw_matrix = matrix_obj._matrix  # 2-D list-of-lists

    # ── Step 3: AHP weights ──────────────────────────────────────────────
    if ahp_config:
        weights, cr = compute_ahp_weights(ahp_config.get("pairwise"))
    else:
        from decision_engine.ahp import DEFAULT_WEIGHTS, DEFAULT_CR
        weights, cr = DEFAULT_WEIGHTS, DEFAULT_CR

    if verbose:
        for crit, w in zip(CRITERIA, weights):
            print(f"  AHP weight  {crit:<18} {w:.4f}")
        print(f"  Consistency Ratio: {cr:.4f}")

    # ── Step 4: TOPSIS scoring ───────────────────────────────────────────
    topsis_results = topsis_with_details(
        matrix=raw_matrix,
        weights=weights,
        crop_names=candidate_names,
        criteria_names=CRITERIA,
    )

    # ── Step 5: ML blend (optional) ─────────────────────────────────────
    if ml_scores:
        for result in topsis_results:
            ml_s = ml_scores.get(result["crop_name"])
            if ml_s is not None:
                blended = (1 - ml_blend_weight) * result["closeness"] + ml_blend_weight * ml_s
                result["suitability_percent"] = round(blended * 100, 2)
                result["ml_blend_applied"] = True
                result["ml_yield_score"] = ml_s
            else:
                result["ml_blend_applied"] = False
                result["ml_yield_score"] = None

    # ── Step 6: Heap-based top-K ranking ────────────────────────────────
    top_crops = get_top_k_crops(topsis_results, k=top_k)

    # ── Step 7: Build final RecommendationResult objects ────────────────
    recommendations: List[RecommendationResult] = []
    for rank, td in enumerate(top_crops, start=1):
        name = td["crop_name"]
        profile = CROP_DB[name]

        reasons = _generate_reasons(name, td, land, profile, lang)
        worst_factors = _generate_worst_factors(td, lang)
        y_lo, y_hi = profile["yield_range_t_ha"]

        rec = RecommendationResult(
            rank=rank,
            crop_name=name,
            suitability_percent=td["suitability_percent"],
            top_reasons=reasons,
            worst_factors=worst_factors,
            expected_yield_range=f"{y_lo} – {y_hi} t/ha",
            best_sowing_window=_sowing_window(profile["season"]),
            market_price_per_kg=profile["market_price_per_kg"],
            season=profile["season"],
            duration_days=profile["duration_days"],
            topsis_scores=td["weighted_scores"],
            ml_blend_applied=td.get("ml_blend_applied", False),
            ml_yield_score=td.get("ml_yield_score"),
        )
        recommendations.append(rec)

    return {
        "recommendations": recommendations,
        "eliminated": eliminated,
        "ahp_weights": dict(zip(CRITERIA, weights)),
        "ahp_cr": round(cr, 4),
        "n_candidates": len(candidate_names),
    }
