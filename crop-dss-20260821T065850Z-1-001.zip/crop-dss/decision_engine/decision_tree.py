"""
decision_tree.py
================
DATA STRUCTURE: Decision Tree  (explicit recursive node structure)
WHY: Hard-elimination rules are naturally hierarchical — some conditions
     (e.g. soil pH out of range) must be checked before any scoring is
     attempted. A decision tree structure makes the elimination logic
     readable, extensible, and provably correct. Each node evaluates one
     condition; leaves return KEEP / ELIMINATE.

This tree runs BEFORE TOPSIS, drastically reducing the candidate set
so that TOPSIS only scores realistically viable crops.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, List, Optional, Tuple
from decision_engine.decision_matrix import LandProfile
from decision_engine.crop_database import CropProfile


# ---------------------------------------------------------------------------
# Decision Tree Nodes
# ---------------------------------------------------------------------------

@dataclass
class TreeNode:
    """
    A single node in the elimination decision tree.

    condition_fn : Callable[[LandProfile, CropProfile], bool]
                   Returns True if the crop PASSES this condition.
    reason       : Human-readable string explaining what this node checks.
    pass_child   : subtree to evaluate if condition passes (None → KEEP)
    fail_child   : subtree to evaluate if condition fails (None → ELIMINATE)
    """
    reason: str
    condition_fn: Callable[[LandProfile, CropProfile], bool]
    pass_child: Optional["TreeNode"] = field(default=None, repr=False)
    fail_child: Optional["TreeNode"] = field(default=None, repr=False)

    def evaluate(
        self,
        land: LandProfile,
        crop: CropProfile,
    ) -> Tuple[bool, str]:
        """
        Recursively evaluate the tree.
        Returns (keep: bool, reason: str)
        """
        passed = self.condition_fn(land, crop)
        if passed:
            if self.pass_child is None:
                return True, f"PASSED: {self.reason}"
            return self.pass_child.evaluate(land, crop)
        else:
            if self.fail_child is None:
                return False, f"ELIMINATED — {self.reason}"
            return self.fail_child.evaluate(land, crop)


# ---------------------------------------------------------------------------
# Condition functions — each takes (LandProfile, CropProfile) → bool
# ---------------------------------------------------------------------------

def _cond_soil_pH(land: LandProfile, crop: CropProfile) -> bool:
    """
    Soil pH must be within the crop's tolerable range ± small buffer.
    Buffer = 0.5 pH units; outside → hard elimination.
    """
    ph_lo, ph_hi = crop["soil_pH_range"]
    buffer = 0.5
    return (ph_lo - buffer) <= land.soil_pH <= (ph_hi + buffer)


def _cond_min_rainfall(land: LandProfile, crop: CropProfile) -> bool:
    """
    Available water (rain + irrigation) must cover at least 50% of crop need.
    If farmer has irrigation, assume 80% coverage at minimum.
    """
    effective_water = land.annual_rainfall_mm
    if land.water_source in ("irrigated", "well"):
        effective_water = max(effective_water, crop["water_need_mm"] * 0.8)
    min_required = crop["min_rainfall_mm"] * 0.5
    return effective_water >= min_required


def _cond_temperature(land: LandProfile, crop: CropProfile) -> bool:
    """
    Average temperature must fall within [min_temp - 5, max_temp + 5] buffer.
    Extreme temperatures outside even the buffer → eliminate.
    """
    t_lo, t_hi = crop["temp_range_C"]
    buffer = 5.0
    return (t_lo - buffer) <= land.avg_temp_C <= (t_hi + buffer)


def _cond_climate_zone(land: LandProfile, crop: CropProfile) -> bool:
    """
    If climate zone is known, crop must support that zone (or zone unknown).
    """
    if land.climate_zone is None:
        return True  # can't check, give benefit of the doubt
    return land.climate_zone in crop.get("climate_zones", [])


def _cond_soil_type_compatible(land: LandProfile, crop: CropProfile) -> bool:
    """
    Crops with very strict soil requirements (black cotton for cotton) that
    are the primary soil type mismatch are soft-eliminated (we keep but flag).
    Here we implement a hard check only for known incompatible combinations.
    """
    incompatible_pairs = {
        # (crop_key, soil_type) → incompatible
        "paddy": ["sandy", "sandy_loam"],  # paddy needs water retention
        "sugarcane": ["sandy"],
    }
    crop_name = crop.get("_name", "")
    if crop_name in incompatible_pairs:
        if land.soil_type.lower() in incompatible_pairs[crop_name]:
            return False
    return True


def _cond_water_need_feasible(land: LandProfile, crop: CropProfile) -> bool:
    """
    Very high water crops (>1000 mm) with only rain-fed source require
    at least 700 mm rainfall to pass hard elimination.
    """
    if crop["water_need_mm"] > 1000 and land.water_source == "rain_fed":
        return land.annual_rainfall_mm >= 700
    return True


# ---------------------------------------------------------------------------
# Build the elimination tree
# ---------------------------------------------------------------------------

def build_elimination_tree() -> TreeNode:
    """
    Construct and return the root of the decision tree.

    Tree structure (top to bottom = most to least critical):

        [soil_pH feasible?]
            NO  → ELIMINATE (soil chemistry is hardest to fix)
            YES → [temperature feasible?]
                      NO  → ELIMINATE
                      YES → [minimum rainfall / water feasible?]
                                NO  → ELIMINATE
                                YES → [water need feasible for rain-fed?]
                                          NO  → ELIMINATE
                                          YES → [climate zone match?]
                                                    NO  → ELIMINATE
                                                    YES → KEEP (proceed to TOPSIS)
    """

    climate_node = TreeNode(
        reason="Climate zone is compatible with this crop",
        condition_fn=_cond_climate_zone,
        pass_child=None,   # KEEP
        fail_child=None,   # ELIMINATE
    )

    water_need_node = TreeNode(
        reason="High-water crop is feasible with available water source",
        condition_fn=_cond_water_need_feasible,
        pass_child=climate_node,
        fail_child=None,   # ELIMINATE
    )

    rain_node = TreeNode(
        reason="Minimum rainfall or irrigation covers crop water needs",
        condition_fn=_cond_min_rainfall,
        pass_child=water_need_node,
        fail_child=None,   # ELIMINATE
    )

    temp_node = TreeNode(
        reason="Temperature range is within acceptable bounds for this crop",
        condition_fn=_cond_temperature,
        pass_child=rain_node,
        fail_child=None,   # ELIMINATE
    )

    root = TreeNode(
        reason="Soil pH is within tolerable range (±0.5 buffer) for this crop",
        condition_fn=_cond_soil_pH,
        pass_child=temp_node,
        fail_child=None,   # ELIMINATE
    )

    return root


# ---------------------------------------------------------------------------
# Public API: filter crops using the decision tree
# ---------------------------------------------------------------------------

def eliminate_crops(
    crop_db: dict,
    land: LandProfile,
    verbose: bool = False,
) -> Tuple[List[str], List[dict]]:
    """
    Run the decision tree against every crop in crop_db.

    Returns
    -------
    kept      : list of crop names that passed all checks
    eliminated: list of {"crop": name, "reason": str} dicts
    """
    root = build_elimination_tree()
    kept: List[str] = []
    eliminated: List[dict] = []

    for crop_name, profile in crop_db.items():
        # Inject the crop name into the profile dict temporarily
        profile_with_name = {**profile, "_name": crop_name}
        keep, reason = root.evaluate(land, profile_with_name)

        if keep:
            kept.append(crop_name)
            if verbose:
                print(f"  ✓ {crop_name:<20} KEPT")
        else:
            eliminated.append({"crop": crop_name, "reason": reason})
            if verbose:
                print(f"  ✗ {crop_name:<20} {reason}")

    return kept, eliminated
