"""
heap_ranker.py
==============
DATA STRUCTURE: Min-Heap (Priority Queue)
WHY: To extract the top-N crops by suitability score in O(n log k) time
     (where k = top count requested), instead of sorting the full list
     O(n log n). For large crop databases this is meaningful. We implement
     the heap manually using a list + sift-up / sift-down operations so the
     DSA mechanics are explicit.

The heap stores (score, crop_name) pairs. We use a min-heap of fixed size k:
  - Push each crop
  - If heap size > k, pop the minimum (lowest score)
  - Result: heap contains the top-k crops
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Any


# ---------------------------------------------------------------------------
# Heap entry — (suitability_score, crop_name, full_result_dict)
# ---------------------------------------------------------------------------

@dataclass(order=True)
class HeapEntry:
    """
    Comparable entry stored in the heap.
    Ordering is by score only (Python compares dataclass fields in order).
    """
    score: float
    crop_name: str = field(compare=False)
    data: Dict[str, Any] = field(default_factory=dict, compare=False)


# ---------------------------------------------------------------------------
# Explicit Min-Heap implementation
# ---------------------------------------------------------------------------

class MinHeap:
    """
    A min-heap implemented on a plain Python list.

    Invariant: heap[0] always holds the minimum entry.
    Child of index i → left: 2i+1, right: 2i+2
    Parent of index i → (i-1) // 2
    """

    def __init__(self) -> None:
        self._data: List[HeapEntry] = []

    # ── Core heap operations ────────────────────────────────────────────

    def push(self, entry: HeapEntry) -> None:
        """Insert element and restore heap property — O(log n)."""
        self._data.append(entry)
        self._sift_up(len(self._data) - 1)

    def pop(self) -> HeapEntry:
        """Remove and return minimum element — O(log n)."""
        if not self._data:
            raise IndexError("pop from an empty heap")
        # Swap root with last element
        self._data[0], self._data[-1] = self._data[-1], self._data[0]
        minimum = self._data.pop()
        if self._data:
            self._sift_down(0)
        return minimum

    def peek(self) -> HeapEntry:
        """Return (but don't remove) the minimum element — O(1)."""
        if not self._data:
            raise IndexError("peek at an empty heap")
        return self._data[0]

    def size(self) -> int:
        return len(self._data)

    # ── Sift operations ─────────────────────────────────────────────────

    def _sift_up(self, idx: int) -> None:
        """Bubble element at idx up until heap property is restored."""
        while idx > 0:
            parent = (idx - 1) // 2
            if self._data[idx] < self._data[parent]:
                self._data[idx], self._data[parent] = (
                    self._data[parent], self._data[idx]
                )
                idx = parent
            else:
                break

    def _sift_down(self, idx: int) -> None:
        """Push element at idx down until heap property is restored."""
        n = len(self._data)
        while True:
            smallest = idx
            left = 2 * idx + 1
            right = 2 * idx + 2

            if left < n and self._data[left] < self._data[smallest]:
                smallest = left
            if right < n and self._data[right] < self._data[smallest]:
                smallest = right

            if smallest == idx:
                break
            self._data[idx], self._data[smallest] = (
                self._data[smallest], self._data[idx]
            )
            idx = smallest

    def to_sorted_list(self) -> List[HeapEntry]:
        """Extract all entries sorted descending by score (best first)."""
        # Pop all to get ascending order, then reverse
        copy = MinHeap()
        copy._data = list(self._data)  # shallow copy
        result = []
        while copy.size() > 0:
            result.append(copy.pop())
        result.reverse()  # min-heap gives ascending; reverse for descending
        return result


# ---------------------------------------------------------------------------
# Top-K Ranking using the heap
# ---------------------------------------------------------------------------

def get_top_k_crops(
    scored_crops: List[Dict[str, Any]],
    k: int = 5,
    score_key: str = "suitability_percent",
) -> List[Dict[str, Any]]:
    """
    Given a list of scored crop dicts, return the top-k using a min-heap.

    Algorithm (O(n log k)):
      1. Push first k items onto the min-heap
      2. For each remaining item, if its score > heap minimum → pop + push
      3. Extract and reverse-sort the heap contents

    Parameters
    ----------
    scored_crops : list of dicts containing at least {score_key, crop_name, ...}
    k            : number of top crops to return
    score_key    : dict key holding the numeric score

    Returns
    -------
    list of top-k dicts, sorted best-first
    """
    heap = MinHeap()
    k = min(k, len(scored_crops))

    for crop_dict in scored_crops:
        score = crop_dict.get(score_key, 0.0)
        entry = HeapEntry(score=score, crop_name=crop_dict["crop_name"], data=crop_dict)

        if heap.size() < k:
            # Heap not full yet — push unconditionally
            heap.push(entry)
        elif score > heap.peek().score:
            # New score beats the current minimum → replace it
            heap.pop()
            heap.push(entry)

    # Extract in descending order (best first)
    sorted_entries = heap.to_sorted_list()
    return [e.data for e in sorted_entries]
