"""
ahp.py
======
Analytic Hierarchy Process (AHP) — criteria weight derivation.

PURPOSE: AHP converts expert judgement (pairwise comparisons of criteria
         importance) into a consistent set of weights that sum to 1.0.
         These weights feed directly into TOPSIS.

DATA STRUCTURE: 2D Matrix (list-of-lists)
WHY: AHP requires matrix multiplication and column-normalisation on the
     n×n pairwise comparison matrix. A plain list-of-lists makes each
     step transparent.

Reference: Saaty, T.L. (1980). The Analytic Hierarchy Process.
"""

from __future__ import annotations
import math
from typing import List, Dict, Tuple


# ---------------------------------------------------------------------------
# Saaty's random consistency index table (n = 1..10)
# ---------------------------------------------------------------------------
RANDOM_INDEX: Dict[int, float] = {
    1: 0.00, 2: 0.00, 3: 0.58, 4: 0.90, 5: 1.12,
    6: 1.24, 7: 1.32, 8: 1.41, 9: 1.45, 10: 1.49,
}

# ---------------------------------------------------------------------------
# Default expert-defined pairwise comparison matrix
# Criteria order (matches decision_matrix.py CRITERIA list):
#   0: soil_fit  1: water_fit  2: temp_fit  3: rainfall_fit
#   4: market_demand  5: expected_yield
#
# Entry [i][j] = "how much more important is criterion i than criterion j?"
#   Scale: 1 = equally, 3 = moderately, 5 = strongly, 9 = extremely
#   Reciprocal below the diagonal is auto-enforced.
#
# Expert rationale:
#   soil_fit is most important (wrong soil → crop fails)
#   water_fit ≈ rainfall_fit (irrigation strategy)
#   temp_fit important but Tamil Nadu is warm year-round
#   market_demand > expected_yield (farmers are price-sensitive)
# ---------------------------------------------------------------------------
DEFAULT_PAIRWISE: List[List[float]] = [
    #  soil  water  temp   rain   mkt    yield
    [  1.0,   2.0,  3.0,   2.0,  3.0,   4.0 ],  # soil_fit
    [  0.5,   1.0,  2.0,   1.0,  2.0,   3.0 ],  # water_fit
    [  1/3,   0.5,  1.0,   0.5,  2.0,   2.0 ],  # temp_fit
    [  0.5,   1.0,  2.0,   1.0,  2.0,   3.0 ],  # rainfall_fit
    [  1/3,   0.5,  0.5,   0.5,  1.0,   2.0 ],  # market_demand
    [  0.25,  1/3,  0.5,   1/3,  0.5,   1.0 ],  # expected_yield
]


def compute_ahp_weights(
    pairwise: List[List[float]] = DEFAULT_PAIRWISE,
    check_consistency: bool = True,
) -> Tuple[List[float], float]:
    """
    Derive normalised AHP weights from a pairwise comparison matrix.

    Steps
    -----
    1. Normalise each column by its sum → normalised matrix
    2. Average each row → priority vector (weights)
    3. Compute consistency ratio (CR) as a sanity check

    Returns
    -------
    weights : list of floats summing to 1.0
    CR      : consistency ratio (should be < 0.10 for acceptable matrix)
    """
    n = len(pairwise)

    # ── Step 1: Column normalisation ────────────────────────────────────
    col_sums: List[float] = [0.0] * n
    for row in pairwise:
        for j, val in enumerate(row):
            col_sums[j] += val

    normalised: List[List[float]] = [
        [pairwise[i][j] / col_sums[j] for j in range(n)]
        for i in range(n)
    ]

    # ── Step 2: Row average → priority vector ───────────────────────────
    weights: List[float] = [
        sum(normalised[i]) / n for i in range(n)
    ]

    # ── Step 3: Consistency check ────────────────────────────────────────
    cr = _compute_consistency_ratio(pairwise, weights, n)

    if check_consistency and cr > 0.10:
        raise ValueError(
            f"AHP pairwise matrix is inconsistent (CR={cr:.3f} > 0.10). "
            "Please revise the expert comparison values."
        )

    return weights, cr


def _compute_consistency_ratio(
    pairwise: List[List[float]],
    weights: List[float],
    n: int,
) -> float:
    """Compute Saaty's Consistency Ratio (CR = CI / RI)."""
    # Weighted sum vector = pairwise × weights
    weighted_sum = [
        sum(pairwise[i][j] * weights[j] for j in range(n))
        for i in range(n)
    ]

    # Lambda max = average of (weighted_sum[i] / weights[i])
    lambda_max = sum(
        weighted_sum[i] / weights[i] for i in range(n) if weights[i] > 0
    ) / n

    ci = (lambda_max - n) / (n - 1) if n > 1 else 0.0
    ri = RANDOM_INDEX.get(n, 1.49)
    cr = ci / ri if ri > 0 else 0.0
    return cr


def load_weights_from_config(config: Dict) -> Tuple[List[float], float]:
    """
    Alternative: load a pairwise matrix from a config dict.
    Expects config['pairwise'] = List[List[float]].
    """
    matrix = config.get("pairwise", DEFAULT_PAIRWISE)
    return compute_ahp_weights(matrix)


# Convenience: pre-computed default weights (used if no config is provided)
DEFAULT_WEIGHTS, DEFAULT_CR = compute_ahp_weights(DEFAULT_PAIRWISE)
