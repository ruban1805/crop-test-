"""
decision_matrix.py
==================
DATA STRUCTURE: 2D Matrix  (list-of-lists — explicit, not numpy hidden magic)
WHY: TOPSIS requires operating on rows (crops) × columns (criteria) — a 2D
     matrix is the exact mathematical representation of a decision table.
     We keep it as a plain Python list-of-lists so every cell access is
     transparent to the DSA evaluator.

Each row  = one candidate crop
Each col  = one criterion score (0.0 – 1.0 after normalisation)
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Optional
import math


# ---------------------------------------------------------------------------
# Criteria identifiers (column indices — fixed order matters for AHP weights)
# ---------------------------------------------------------------------------
CRITERIA = [
    "soil_fit",        # 0
    "water_fit",       # 1
    "temp_fit",        # 2
    "rainfall_fit",    # 3
    "market_demand",   # 4
    "expected_yield",  # 5
]
N_CRITERIA = len(CRITERIA)


# ---------------------------------------------------------------------------
# Land profile dataclass — what the farmer provides (or APIs fill in)
# ---------------------------------------------------------------------------
@dataclass
class LandProfile:
    """Holds all input data for a farmer's land parcel."""
    latitude: float
    longitude: float
    soil_pH: float
    soil_type: str                           # e.g. 'loam', 'black_cotton'
    water_source: str                        # 'rain_fed' | 'irrigated' | 'well'
    land_size_ha: float
    avg_temp_C: float                        # mean annual / seasonal temp
    annual_rainfall_mm: float                # total expected seasonal rainfall
    forecast_rainfall_mm: Optional[float] = None  # next 60-day forecast
    ndvi: Optional[float] = None            # satellite vegetation index
    climate_zone: Optional[str] = None      # Koppen code e.g. 'BSh'
    # Additional fields filled by APIs
    soil_organic_carbon: Optional[float] = None
    soil_texture: Optional[str] = None


# ---------------------------------------------------------------------------
# Single row in the decision matrix
# ---------------------------------------------------------------------------
@dataclass
class DecisionRow:
    crop_name: str
    scores: List[float] = field(default_factory=lambda: [0.0] * N_CRITERIA)
    raw_values: Dict[str, float] = field(default_factory=dict)

    def __getitem__(self, idx: int) -> float:
        return self.scores[idx]

    def __setitem__(self, idx: int, val: float) -> None:
        self.scores[idx] = val


# ---------------------------------------------------------------------------
# 2D Decision Matrix
# ---------------------------------------------------------------------------
class DecisionMatrix:
    """
    Explicit 2-D matrix: rows = crops, columns = criteria.

    Internal representation
    -----------------------
    self._matrix : List[List[float]]   — the raw numbers
    self._rows   : List[DecisionRow]   — parallel list carrying crop name +
                                         raw values alongside scores
    self._criteria : List[str]         — column labels (order preserved)
    """

    def __init__(self, criteria: List[str] = CRITERIA):
        self._criteria: List[str] = criteria
        self._matrix: List[List[float]] = []   # 2-D list-of-lists
        self._rows: List[DecisionRow] = []

    # ── Building the matrix ────────────────────────────────────────────

    def add_row(self, row: DecisionRow) -> None:
        """Append a crop row; keeps _matrix and _rows in sync."""
        self._matrix.append(list(row.scores))  # shallow copy of scores list
        self._rows.append(row)

    def build_from_profiles(
        self,
        crop_names: List[str],
        land: LandProfile,
        crop_db: dict,
    ) -> None:
        """
        Populate the decision matrix by scoring each crop against the land profile.
        Scoring functions return a value in [0.0, 1.0].
        """
        self._matrix = []
        self._rows = []

        for name in crop_names:
            profile = crop_db[name]
            row = DecisionRow(crop_name=name)

            sf = _score_soil_fit(land.soil_pH, land.soil_type, profile)
            wf = _score_water_fit(land.water_source, land.annual_rainfall_mm, profile)
            tf = _score_temp_fit(land.avg_temp_C, profile)
            rf = _score_rainfall_fit(land.annual_rainfall_mm, profile)
            md = _score_market_demand(profile)
            ey = _score_expected_yield(profile)

            row.scores = [sf, wf, tf, rf, md, ey]
            row.raw_values = {
                "soil_pH_input": land.soil_pH,
                "soil_pH_range": str(profile["soil_pH_range"]),
                "water_need_mm": profile["water_need_mm"],
                "annual_rainfall_mm": land.annual_rainfall_mm,
                "avg_temp_C": land.avg_temp_C,
                "temp_range_C": str(profile["temp_range_C"]),
                "market_price_per_kg": profile["market_price_per_kg"],
                "yield_range_t_ha": str(profile["yield_range_t_ha"]),
            }

            self._matrix.append(list(row.scores))
            self._rows.append(row)

    # ── Matrix access helpers ───────────────────────────────────────────

    def get_cell(self, row_idx: int, col_idx: int) -> float:
        """O(1) cell access in the 2-D matrix."""
        return self._matrix[row_idx][col_idx]

    def get_column(self, col_idx: int) -> List[float]:
        """Return all values for a given criterion (column)."""
        return [self._matrix[r][col_idx] for r in range(len(self._matrix))]

    def n_rows(self) -> int:
        return len(self._matrix)

    def n_cols(self) -> int:
        return len(self._criteria)

    def crop_names(self) -> List[str]:
        return [row.crop_name for row in self._rows]

    def get_row(self, idx: int) -> DecisionRow:
        return self._rows[idx]

    def __repr__(self) -> str:
        header = f"{'Crop':<20}" + "".join(f"{c:>14}" for c in self._criteria)
        lines = [header, "-" * (20 + 14 * N_CRITERIA)]
        for r, row in enumerate(self._rows):
            cells = "".join(f"{self._matrix[r][c]:>14.4f}" for c in range(N_CRITERIA))
            lines.append(f"{row.crop_name:<20}{cells}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Individual scoring functions — each returns float in [0.0, 1.0]
# ---------------------------------------------------------------------------

def _bell(value: float, lo: float, hi: float) -> float:
    """
    Smooth trapezoidal scoring:
      - Returns 1.0 if value is within [lo, hi]
      - Falls off linearly outside, clamped to [0, 1]
    WHY: Avoid hard cliffs; a pH of 5.4 for a crop with min 5.5 shouldn't
         score the same zero as pH 3.0.
    """
    if lo <= value <= hi:
        return 1.0
    margin = (hi - lo) * 0.5 if hi != lo else 0.5
    if value < lo:
        return max(0.0, 1.0 - (lo - value) / margin)
    else:  # value > hi
        return max(0.0, 1.0 - (value - hi) / margin)


def _score_soil_fit(soil_pH: float, soil_type: str, profile: dict) -> float:
    ph_lo, ph_hi = profile["soil_pH_range"]
    ph_score = _bell(soil_pH, ph_lo, ph_hi)

    # Bonus if soil type matches crop's preferred list
    soil_match = 1.0 if soil_type.lower() in [s.lower() for s in profile["soil_types"]] else 0.5
    return 0.7 * ph_score + 0.3 * soil_match


def _score_water_fit(water_source: str, rainfall_mm: float, profile: dict) -> float:
    need = profile["water_need_mm"]
    # If irrigated, assume adequate supply; if rain-fed use actual rainfall
    supply = rainfall_mm if water_source == "rain_fed" else max(rainfall_mm, need)
    ratio = min(supply / need, 2.0) if need > 0 else 1.0
    # Penalise both deficit AND large excess (waterlogging)
    if ratio < 1.0:
        return ratio                    # under-supply → proportional penalty
    elif ratio <= 1.3:
        return 1.0                      # sweet spot
    else:
        return max(0.5, 1.0 - (ratio - 1.3) * 0.3)


def _score_temp_fit(avg_temp: float, profile: dict) -> float:
    t_lo, t_hi = profile["temp_range_C"]
    return _bell(avg_temp, t_lo, t_hi)


def _score_rainfall_fit(rainfall_mm: float, profile: dict) -> float:
    r_lo = profile["min_rainfall_mm"]
    r_hi = profile["max_rainfall_mm"]
    return _bell(rainfall_mm, r_lo, r_hi)


def _score_market_demand(profile: dict) -> float:
    """
    Normalise market price relative to the price range in the crop DB.
    Using a fixed scale: < ₹10/kg → 0.2, > ₹120/kg → 1.0.
    """
    price = profile["market_price_per_kg"]
    # logarithmic normalisation so high prices don't dominate
    score = math.log1p(price) / math.log1p(150)
    return min(1.0, max(0.0, score))


def _score_expected_yield(profile: dict) -> float:
    """
    Normalise expected yield (use midpoint of range).
    Reference max: paddy tops at ~6 t/ha for grain; banana 45 t/ha fruits.
    Use log-normalisation to compare across very different yield scales.
    """
    y_lo, y_hi = profile["yield_range_t_ha"]
    midpoint = (y_lo + y_hi) / 2.0
    # cap reference at 50 t/ha
    score = math.log1p(midpoint) / math.log1p(50)
    return min(1.0, max(0.0, score))
