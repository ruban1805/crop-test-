# Decision Engine package
# This module implements the MCDM pipeline:
#   crop_db (HashMap) → decision matrix (2D Matrix) →
#   elimination (Decision Tree) → AHP weights → TOPSIS scorer →
#   heap-based ranker (Priority Queue)
