"""
weather_api.py
==============
NASA POWER API client — free, no approval required.
Endpoint: https://power.larc.nasa.gov/api/temporal/daily/point

Returns daily historical and climatological data for a lat/long.
Also supports IMD as a drop-in replacement when credentials are available.

DATA USED:
  PRECTOTCORR  — precipitation corrected (mm/day)
  T2M          — temperature at 2m (°C)
  T2M_MAX      — max temp at 2m
  T2M_MIN      — min temp at 2m
  ALLSKY_SFC_SW_DWN — solar radiation (MJ/m²/day) — for evapotranspiration
"""

from __future__ import annotations
import httpx
import asyncio
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass


NASA_POWER_BASE = "https://power.larc.nasa.gov/api/temporal/daily/point"


@dataclass
class WeatherData:
    """Parsed weather data for a location."""
    latitude: float
    longitude: float
    period_start: str
    period_end: str
    daily_rainfall_mm: List[float]     # ordered by date
    daily_temp_avg_C: List[float]
    daily_temp_max_C: List[float]
    daily_temp_min_C: List[float]
    total_rainfall_mm: float
    avg_temp_C: float
    source: str = "NASA_POWER"


async def fetch_nasa_power(
    latitude: float,
    longitude: float,
    days_back: int = 365,
) -> WeatherData:
    """
    Fetch daily weather data from NASA POWER API.

    Parameters
    ----------
    latitude    : decimal degrees
    longitude   : decimal degrees
    days_back   : how many days of historical data to retrieve

    Returns
    -------
    WeatherData dataclass
    """
    end_date = datetime.utcnow() - timedelta(days=7)  # POWER has ~7 day lag
    start_date = end_date - timedelta(days=days_back)

    params = {
        "parameters": "PRECTOTCORR,T2M,T2M_MAX,T2M_MIN",
        "community": "AG",
        "longitude": longitude,
        "latitude": latitude,
        "start": start_date.strftime("%Y%m%d"),
        "end": end_date.strftime("%Y%m%d"),
        "format": "JSON",
    }

    async with httpx.AsyncClient(timeout=15.0) as client:
        response = await client.get(NASA_POWER_BASE, params=params)
        response.raise_for_status()
        data = response.json()

    props = data["properties"]["parameter"]
    rainfall_dict = props.get("PRECTOTCORR", {})
    temp_dict     = props.get("T2M", {})
    temp_max_dict = props.get("T2M_MAX", {})
    temp_min_dict = props.get("T2M_MIN", {})

    # Extract ordered lists — NASA POWER keys are "YYYYMMDD" strings
    sorted_dates = sorted(rainfall_dict.keys())

    daily_rain = [max(0.0, float(rainfall_dict.get(d, 0))) for d in sorted_dates]
    daily_temp = [float(temp_dict.get(d, 25.0)) for d in sorted_dates]
    daily_max  = [float(temp_max_dict.get(d, 30.0)) for d in sorted_dates]
    daily_min  = [float(temp_min_dict.get(d, 20.0)) for d in sorted_dates]

    total_rain = sum(daily_rain)
    avg_temp   = sum(daily_temp) / max(len(daily_temp), 1)

    return WeatherData(
        latitude=latitude,
        longitude=longitude,
        period_start=sorted_dates[0] if sorted_dates else "",
        period_end=sorted_dates[-1] if sorted_dates else "",
        daily_rainfall_mm=daily_rain,
        daily_temp_avg_C=daily_temp,
        daily_temp_max_C=daily_max,
        daily_temp_min_C=daily_min,
        total_rainfall_mm=round(total_rain, 2),
        avg_temp_C=round(avg_temp, 2),
        source="NASA_POWER",
    )


async def fetch_weather_forecast(
    latitude: float,
    longitude: float,
    forecast_days: int = 30,
) -> Dict:
    """
    NASA POWER forecast climatology — use seasonal normals as proxy forecast
    when real-time forecast API (IMD) is not available.
    
    Returns dict with forecast_rainfall_mm (total) and forecast_temp_avg_C.
    """
    # Use climatological normals: fetch long-period average
    # NASA POWER climatology endpoint
    clim_url = "https://power.larc.nasa.gov/api/climatology/point"
    params = {
        "parameters": "PRECTOTCORR,T2M",
        "community": "AG",
        "longitude": longitude,
        "latitude": latitude,
        "format": "JSON",
        "start": 2001,
        "end": 2020,
    }

    async with httpx.AsyncClient(timeout=15.0) as client:
        try:
            response = await client.get(clim_url, params=params)
            response.raise_for_status()
            data = response.json()
            props = data["properties"]["parameter"]

            # Monthly climatological values
            monthly_rain = props.get("PRECTOTCORR", {})
            monthly_temp = props.get("T2M", {})

            # Pick current + next months
            now = datetime.utcnow()
            months = [(now.month + i - 1) % 12 + 1 for i in range(2)]
            month_keys = [str(m) for m in months]

            forecast_rain = sum(
                float(monthly_rain.get(k, {}).get("ANN", 5.0)) * 30
                for k in month_keys
            ) / 2 * (forecast_days / 30)

            forecast_temp = sum(
                float(monthly_temp.get(k, {}).get("ANN", 28.0))
                for k in month_keys
            ) / len(month_keys)

            return {
                "forecast_rainfall_mm": round(forecast_rain, 1),
                "forecast_temp_avg_C": round(forecast_temp, 1),
                "source": "NASA_POWER_CLIMATOLOGY",
                "forecast_days": forecast_days,
            }
        except Exception:
            # Fallback: return reasonable defaults for Tamil Nadu
            return {
                "forecast_rainfall_mm": 150.0 * (forecast_days / 30),
                "forecast_temp_avg_C": 28.5,
                "source": "DEFAULT_FALLBACK",
                "forecast_days": forecast_days,
            }


def fetch_weather_sync(
    latitude: float,
    longitude: float,
    days_back: int = 365,
) -> WeatherData:
    """Synchronous wrapper for use outside async context (e.g. tests, CLI)."""
    return asyncio.run(fetch_nasa_power(latitude, longitude, days_back))
