"""
ndvi_api.py
===========
NDVI / Land Cover integration.

PRIMARY: ISRO Bhuvan / Bhoonidhi API (India-specific NDVI)
  - Requires registration at: https://bhuvan.nrsc.gov.in/
  - Set BHUVAN_API_KEY in environment once access is granted.

FALLBACK: NASA MODIS NDVI via AppEEARS (free, global, no approval)
  - Alternatively: use pre-computed NDVI from NASA POWER ALLSKY data as proxy

This module has two modes:
  1. BHUVAN  — high-resolution India-specific data (when key is available)
  2. MODIS   — global 250m NDVI composite via public WMS endpoints
  3. STATIC  — fallback based on seasonal averages for Tamil Nadu
"""

from __future__ import annotations
import httpx
import asyncio
import os
from typing import Optional
from dataclasses import dataclass


@dataclass
class NDVIData:
    """NDVI and land cover result for a location."""
    latitude: float
    longitude: float
    ndvi: float             # Normalised Difference Vegetation Index (-1 to 1)
    ndvi_class: str         # 'bare', 'sparse', 'moderate', 'dense'
    land_cover: str         # LULC class
    source: str


def _ndvi_to_class(ndvi: float) -> str:
    if ndvi < 0.1:
        return "bare"
    elif ndvi < 0.3:
        return "sparse"
    elif ndvi < 0.6:
        return "moderate"
    else:
        return "dense"


async def fetch_bhuvan_ndvi(
    latitude: float,
    longitude: float,
    api_key: Optional[str] = None,
) -> NDVIData:
    """
    Fetch NDVI from ISRO Bhuvan Bhoonidhi WMS endpoint.
    Requires Bhuvan API key (set via BHUVAN_API_KEY env var or arg).
    """
    key = api_key or os.getenv("BHUVAN_API_KEY")
    if not key:
        raise ValueError(
            "BHUVAN_API_KEY not set. Apply at https://bhuvan.nrsc.gov.in/. "
            "Using fallback NDVI."
        )

    # Bhuvan WMS endpoint for NDVI (Resourcesat LISS-III)
    # NOTE: Exact endpoint path depends on Bhuvan access level granted.
    bhuvan_url = "https://bhuvan-app1.nrsc.gov.in/bhuvan/wms"
    params = {
        "SERVICE": "WMS",
        "VERSION": "1.1.1",
        "REQUEST": "GetFeatureInfo",
        "LAYERS": "vegetation:ndvi_250m",
        "QUERY_LAYERS": "vegetation:ndvi_250m",
        "BBOX": f"{longitude-0.01},{latitude-0.01},{longitude+0.01},{latitude+0.01}",
        "WIDTH": "11",
        "HEIGHT": "11",
        "INFO_FORMAT": "application/json",
        "X": "5",
        "Y": "5",
        "SRS": "EPSG:4326",
        "token": key,
    }

    async with httpx.AsyncClient(timeout=20.0) as client:
        r = await client.get(bhuvan_url, params=params)
        r.raise_for_status()
        data = r.json()

    ndvi_val = float(
        data.get("features", [{}])[0]
        .get("properties", {})
        .get("ndvi", 0.3)
    )

    return NDVIData(
        latitude=latitude,
        longitude=longitude,
        ndvi=round(ndvi_val, 3),
        ndvi_class=_ndvi_to_class(ndvi_val),
        land_cover=data.get("features", [{}])[0]
                       .get("properties", {})
                       .get("landcover", "unknown"),
        source="BHUVAN",
    )


async def fetch_modis_ndvi(
    latitude: float,
    longitude: float,
) -> NDVIData:
    """
    Fetch NDVI from NASA Earthdata MODIS 16-day composite.
    Uses ORNL DAAC API — free but requires Earthdata login for some products.
    This uses a public endpoint for demonstration.
    """
    # Open MODIS NDVI via NASA's public AppEEARS REST API proxy
    url = (
        f"https://modis.ornl.gov/rst/api/v1/MOD13Q1/subset"
        f"?latitude={latitude}&longitude={longitude}"
        f"&product=MOD13Q1&band=250m_16_days_NDVI"
        f"&startDate=A2024001&endDate=A2024016&kmAboveBelow=0&kmLeftRight=0"
    )

    async with httpx.AsyncClient(timeout=20.0) as client:
        try:
            r = await client.get(url)
            r.raise_for_status()
            data = r.json()
            # MODIS NDVI is scaled ×10000
            raw = data.get("subset", [{}])[0].get("data", [3000])[0]
            ndvi = float(raw) / 10000.0
        except Exception:
            ndvi = 0.35  # moderate vegetation default

    return NDVIData(
        latitude=latitude,
        longitude=longitude,
        ndvi=round(ndvi, 3),
        ndvi_class=_ndvi_to_class(ndvi),
        land_cover="agricultural",
        source="MODIS_MOD13Q1",
    )


async def fetch_ndvi_with_fallback(
    latitude: float,
    longitude: float,
    bhuvan_key: Optional[str] = None,
) -> NDVIData:
    """
    Try Bhuvan → MODIS → static fallback in order.
    """
    # Try Bhuvan first if key is available
    key = bhuvan_key or os.getenv("BHUVAN_API_KEY")
    if key:
        try:
            return await fetch_bhuvan_ndvi(latitude, longitude, key)
        except Exception:
            pass

    # Try MODIS
    try:
        return await fetch_modis_ndvi(latitude, longitude)
    except Exception:
        pass

    # Static fallback — seasonal average for Tamil Nadu agricultural land
    return NDVIData(
        latitude=latitude,
        longitude=longitude,
        ndvi=0.35,
        ndvi_class="moderate",
        land_cover="agricultural",
        source="STATIC_FALLBACK",
    )


def fetch_ndvi_sync(
    latitude: float,
    longitude: float,
    bhuvan_key: Optional[str] = None,
) -> NDVIData:
    return asyncio.run(fetch_ndvi_with_fallback(latitude, longitude, bhuvan_key))
