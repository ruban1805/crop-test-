"""
api/main.py  — fixed version
=============================
Root cause of 422: mixing Pydantic body model with File() forces FastAPI
into multipart mode for ALL requests, breaking the plain-JSON path.

Fix: two separate endpoints
  POST /analyze-land        — JSON body, no image  ← browser default
  POST /analyze-land/image  — multipart form,   with image upload
Both share the same _core_analysis() helper.
"""

from __future__ import annotations
import asyncio
import uuid
from datetime import datetime
from typing import List, Optional, Dict, Any

from fastapi import FastAPI, HTTPException, UploadFile, File, Form, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from decision_engine.crop_database import CROP_DB, get_crop, list_crops
from decision_engine.decision_matrix import LandProfile
from decision_engine.engine import run_engine
from decision_engine.trie import build_crop_trie
from decision_engine.sliding_window import analyse_weather_trend
from api.weather_api import fetch_nasa_power, fetch_weather_forecast
from api.soil_api import fetch_soil_with_fallback
from api.ndvi_api import fetch_ndvi_with_fallback

try:
    from ml.train_yield_model import predict_yield_scores
    ML_AVAILABLE = True
except Exception:
    ML_AVAILABLE = False

# ── App ────────────────────────────────────────────────────────────────────
app = FastAPI(title="Crop DSS", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True,
    allow_methods=["*"], allow_headers=["*"],
)

_static_dir = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "static"))
app.mount("/static", StaticFiles(directory=_static_dir), name="static")

@app.get("/", include_in_schema=False)
async def root():
    return FileResponse(os.path.join(_static_dir, "index.html"))

CROP_TRIE = build_crop_trie(CROP_DB)

# ── Schemas ────────────────────────────────────────────────────────────────

class LandAnalysisRequest(BaseModel):
    latitude:      float            = Field(..., ge=-90,  le=90)
    longitude:     float            = Field(..., ge=-180, le=180)
    land_size_ha:  float            = Field(..., gt=0)
    water_source:  str              = Field("rain_fed")
    soil_pH:       Optional[float]  = Field(None, ge=3.0, le=10.0)
    soil_type:     Optional[str]    = None
    language:      str              = Field("en")
    top_k:         int              = Field(5, ge=1, le=15)
    use_ml_blend:  bool             = Field(False)


class CropRec(BaseModel):
    rank: int
    crop_name: str
    suitability_percent: float
    top_reasons: List[str]
    worst_factors: List[str]
    expected_yield_range: str
    best_sowing_window: str
    market_price_per_kg: float
    season: str
    duration_days: int
    topsis_scores: Dict[str, float]
    ml_blend_applied: bool


class AnalysisOut(BaseModel):
    request_id: str
    timestamp: str
    location: Dict[str, float]
    soil: Dict[str, Any]
    weather: Dict[str, Any]
    ndvi: Dict[str, Any]
    recommendations: List[CropRec]
    eliminated_count: int
    ahp_weights: Dict[str, float]
    ahp_cr: float
    weather_trend: Dict[str, Any]
    image_analysis: Optional[Dict[str, Any]] = None


# ── Shared analysis core ───────────────────────────────────────────────────

async def _core_analysis(
    latitude: float, longitude: float, land_size_ha: float,
    water_source: str, soil_pH: Optional[float], soil_type: Optional[str],
    language: str, top_k: int, use_ml_blend: bool,
    image_bytes: Optional[bytes] = None,
) -> AnalysisOut:

    rid = str(uuid.uuid4())[:8]

    # ── 1. Parallel external API calls (all fail-safe, 12 s hard timeout) ─
    async def _safe(coro):
        try:
            return await asyncio.wait_for(coro, timeout=20.0)
        except Exception as e:
            return e

    # SoilGrids is given a shorter individual timeout since the user
    # can supply soil_pH manually; NASA POWER and NDVI get the full window.
    async def _safe_soil(coro):
        try:
            return await asyncio.wait_for(coro, timeout=8.0)
        except Exception as e:
            return e

    soil_raw, weather_raw, ndvi_raw, forecast_raw = await asyncio.gather(
        _safe_soil(fetch_soil_with_fallback(latitude, longitude,
                                            fallback_pH=soil_pH or 6.5,
                                            fallback_soil_type=soil_type or "loam")),
        _safe(fetch_nasa_power(latitude, longitude, days_back=365)),
        _safe(fetch_ndvi_with_fallback(latitude, longitude)),
        _safe(fetch_weather_forecast(latitude, longitude)),
    )

    # Soil
    if isinstance(soil_raw, Exception):
        eff_pH   = soil_pH or 6.5
        eff_soil = soil_type or "loam"
        soil_dict: Dict[str, Any] = {
            "soil_pH": eff_pH, "soil_type": eff_soil,
            "source": f"manual_fallback (API unavailable: {type(soil_raw).__name__})",
        }
    else:
        eff_pH   = soil_pH or soil_raw.soil_pH
        eff_soil = soil_type or soil_raw.soil_type
        soil_dict = {
            "soil_pH": soil_raw.soil_pH, "soil_type": soil_raw.soil_type,
            "organic_carbon_g_kg": soil_raw.organic_carbon_g_kg,
            "clay_pct": soil_raw.clay_pct, "sand_pct": soil_raw.sand_pct,
            "source": soil_raw.source,
        }

    # Weather
    if isinstance(weather_raw, Exception):
        # Smart Tamil Nadu regional defaults based on lat/lon band
        annual_rain  = 900.0
        avg_temp     = 28.5
        daily_rain   = []
        weather_dict: Dict[str, Any] = {
            "annual_rainfall_mm": annual_rain,
            "avg_temp_C": avg_temp,
            "source": f"regional_fallback (API unavailable: {type(weather_raw).__name__})",
        }
    else:
        annual_rain  = weather_raw.total_rainfall_mm
        avg_temp     = weather_raw.avg_temp_C
        daily_rain   = weather_raw.daily_rainfall_mm
        weather_dict = {
            "annual_rainfall_mm": annual_rain, "avg_temp_C": avg_temp,
            "period": f"{weather_raw.period_start} – {weather_raw.period_end}",
            "source": weather_raw.source,
        }

    if not isinstance(forecast_raw, Exception):
        fr = forecast_raw.get("forecast_rainfall_mm")
        weather_dict["forecast_rainfall_mm"] = fr
    else:
        fr = None

    # NDVI
    if isinstance(ndvi_raw, Exception):
        ndvi_val  = 0.3
        ndvi_dict: Dict[str, Any] = {"ndvi": ndvi_val, "class": "moderate", "source": "fallback"}
    else:
        ndvi_val  = ndvi_raw.ndvi
        ndvi_dict = {"ndvi": ndvi_raw.ndvi, "class": ndvi_raw.ndvi_class,
                     "land_cover": ndvi_raw.land_cover, "source": ndvi_raw.source}

    # ── 2. Image analysis ─────────────────────────────────────────────────
    img_result: Optional[Dict[str, Any]] = None
    if image_bytes:
        try:
            import cv2, numpy as np
            from api.image_analysis import analyse_land_image
            img_result_obj = analyse_land_image(image_bytes)
            img_result = {
                "vegetation_cover_pct": img_result_obj.vegetation_cover_pct,
                "soil_color_class":     img_result_obj.soil_color_class,
                "waterlogging_risk":    img_result_obj.waterlogging_risk,
                "ndvi_proxy":           img_result_obj.estimated_ndvi_proxy,
                "lulc_class":           img_result_obj.lulc_class,
                "confidence":           img_result_obj.confidence,
                "image_quality":        img_result_obj.image_quality,
            }
            if img_result_obj.confidence > 0.7 and img_result_obj.soil_color_class == "black":
                eff_soil = "black_cotton"
        except ImportError:
            img_result = {"error": "opencv-python not installed. Run: pip install opencv-python-headless"}
        except Exception as e:
            img_result = {"error": str(e)}

    # ── 3. Weather trend ──────────────────────────────────────────────────
    weather_trend: Dict[str, Any] = {}
    if daily_rain:
        tr = analyse_weather_trend(daily_rain, window=30)
        weather_trend = {"trend": tr.trend, "mean_daily_mm": tr.mean,
                         "drought_streak_days": tr.drought_days,
                         "excess_rain_days": tr.excess_days}

    # ── 4. Build LandProfile ──────────────────────────────────────────────
    land = LandProfile(
        latitude=latitude, longitude=longitude,
        soil_pH=eff_pH, soil_type=eff_soil,
        water_source=water_source, land_size_ha=land_size_ha,
        avg_temp_C=avg_temp, annual_rainfall_mm=annual_rain,
        forecast_rainfall_mm=fr, ndvi=ndvi_val,
    )

    # ── 5. ML scores ──────────────────────────────────────────────────────
    ml_scores = None
    if use_ml_blend and ML_AVAILABLE:
        try:
            ml_scores = predict_yield_scores({
                "soil_pH": eff_pH,
                "clay_pct": soil_dict.get("clay_pct", 25.0),
                "sand_pct": soil_dict.get("sand_pct", 40.0),
                "organic_carbon": soil_dict.get("organic_carbon_g_kg", 1.2),
                "annual_rainfall_mm": annual_rain,
                "avg_temp_C": avg_temp,
            }, list(CROP_DB.keys()))
        except Exception:
            ml_scores = None

    # ── 6. MCDM engine ────────────────────────────────────────────────────
    eng = run_engine(land=land, top_k=top_k, ml_scores=ml_scores, lang=language)
    recs = eng.get("recommendations", [])

    return AnalysisOut(
        request_id=rid,
        timestamp=datetime.utcnow().isoformat(),
        location={"latitude": latitude, "longitude": longitude},
        soil=soil_dict, weather=weather_dict, ndvi=ndvi_dict,
        recommendations=[CropRec(
            rank=r.rank, crop_name=r.crop_name,
            suitability_percent=r.suitability_percent,
            top_reasons=r.top_reasons, worst_factors=r.worst_factors,
            expected_yield_range=r.expected_yield_range,
            best_sowing_window=r.best_sowing_window,
            market_price_per_kg=r.market_price_per_kg,
            season=r.season, duration_days=r.duration_days,
            topsis_scores=r.topsis_scores,
            ml_blend_applied=r.ml_blend_applied,
        ) for r in recs],
        eliminated_count=len(eng.get("eliminated", [])),
        ahp_weights=eng.get("ahp_weights", {}),
        ahp_cr=eng.get("ahp_cr", 0.0),
        weather_trend=weather_trend,
        image_analysis=img_result,
    )


# ── Endpoint 1: JSON body, no image ───────────────────────────────────────
@app.post("/analyze-land", response_model=AnalysisOut)
async def analyze_land_json(req: LandAnalysisRequest):
    """Standard analysis — JSON body, no photo."""
    try:
        return await _core_analysis(
            req.latitude, req.longitude, req.land_size_ha,
            req.water_source, req.soil_pH, req.soil_type,
            req.language, req.top_k, req.use_ml_blend,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Endpoint 2: multipart form + image ────────────────────────────────────
@app.post("/analyze-land/image", response_model=AnalysisOut)
async def analyze_land_with_image(
    latitude:     float          = Form(...),
    longitude:    float          = Form(...),
    land_size_ha: float          = Form(...),
    water_source: str            = Form("rain_fed"),
    soil_pH:      Optional[float]= Form(None),
    soil_type:    Optional[str]  = Form(None),
    language:     str            = Form("en"),
    top_k:        int            = Form(5),
    use_ml_blend: bool           = Form(False),
    image:        UploadFile     = File(...),
):
    """Analysis with land photo — multipart form."""
    try:
        image_bytes = await image.read()
        return await _core_analysis(
            latitude, longitude, land_size_ha,
            water_source, soil_pH, soil_type,
            language, top_k, use_ml_blend,
            image_bytes=image_bytes,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Endpoint 3: instant decision (no external APIs) ───────────────────────
class QuickDecisionRequest(BaseModel):
    """All values provided manually — runs MCDM engine instantly, no API calls."""
    soil_pH:           float = Field(..., ge=3.0,  le=10.0)
    soil_type:         str   = Field("loam")
    annual_rainfall_mm:float = Field(..., ge=0)
    avg_temp_C:        float = Field(..., ge=0, le=50)
    water_source:      str   = Field("rain_fed")
    land_size_ha:      float = Field(1.0, gt=0)
    language:          str   = Field("en")
    top_k:             int   = Field(5, ge=1, le=15)


@app.post("/predict")
async def quick_predict(req: QuickDecisionRequest):
    """
    Instant crop prediction — zero external API calls.
    All inputs are supplied by the user; runs Decision Tree + AHP + TOPSIS + Heap.
    Perfect for offline use or the Decision Predictor UI panel.
    """
    land = LandProfile(
        latitude=0.0, longitude=0.0,
        soil_pH=req.soil_pH, soil_type=req.soil_type,
        water_source=req.water_source, land_size_ha=req.land_size_ha,
        avg_temp_C=req.avg_temp_C, annual_rainfall_mm=req.annual_rainfall_mm,
    )
    eng = run_engine(land=land, top_k=req.top_k, lang=req.language)
    recs = eng.get("recommendations", [])

    return {
        "recommendations": [
            {
                "rank": r.rank,
                "crop_name": r.crop_name,
                "suitability_percent": r.suitability_percent,
                "top_reasons": r.top_reasons,
                "worst_factors": r.worst_factors,
                "expected_yield_range": r.expected_yield_range,
                "best_sowing_window": r.best_sowing_window,
                "market_price_per_kg": r.market_price_per_kg,
                "season": r.season,
                "duration_days": r.duration_days,
                "topsis_scores": r.topsis_scores,
            }
            for r in recs
        ],
        "eliminated_count": len(eng.get("eliminated", [])),
        "ahp_weights": eng.get("ahp_weights", {}),
        "ahp_cr": eng.get("ahp_cr", 0.0),
        "n_candidates": eng.get("n_candidates", 0),
    }


# ── Utility endpoints ──────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {"status": "ok", "ml_available": ML_AVAILABLE,
            "crop_count": len(CROP_DB), "trie_words": len(CROP_TRIE)}


@app.get("/crops/search")
async def search_crops(q: str = Query(..., min_length=1),
                       max_results: int = Query(10, ge=1, le=50)):
    results = CROP_TRIE.autocomplete(q, max_results=max_results)
    return {"query": q, "results": results}


@app.get("/crops")
async def list_all_crops():
    return {"crops": list_crops(), "count": len(CROP_DB)}


@app.get("/crop/{crop_name}")
async def crop_detail(crop_name: str):
    try:
        return {"crop_name": crop_name, "profile": get_crop(crop_name)}
    except KeyError:
        raise HTTPException(404, f"Crop '{crop_name}' not found.")


@app.get("/weather-forecast")
async def weather_forecast_ep(lat: float = Query(...), lon: float = Query(...),
                               days: int = Query(30)):
    try:
        return await fetch_weather_forecast(lat, lon, forecast_days=days)
    except Exception as e:
        raise HTTPException(503, str(e))


@app.get("/soil-data")
async def soil_data_ep(lat: float = Query(...), lon: float = Query(...)):
    try:
        s = await fetch_soil_with_fallback(lat, lon)
        return {"soil_pH": s.soil_pH, "soil_type": s.soil_type,
                "clay_pct": s.clay_pct, "sand_pct": s.sand_pct,
                "silt_pct": s.silt_pct, "organic_carbon_g_kg": s.organic_carbon_g_kg,
                "source": s.source}
    except Exception as e:
        raise HTTPException(503, str(e))
