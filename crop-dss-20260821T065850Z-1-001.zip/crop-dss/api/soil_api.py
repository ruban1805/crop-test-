"""
soil_api.py
===========
SoilGrids (ISRIC) REST API client — free, no approval required.
Endpoint: https://rest.isric.org/soilgrids/v2.0/properties/query

Returns soil pH, texture fractions, organic carbon, bulk density by lat/long.

Documentation: https://www.isric.org/explore/soilgrids/faq-soilgrids
"""

from __future__ import annotations
import httpx
import asyncio
from typing import Dict, Optional
from dataclasses import dataclass


SOILGRIDS_BASE = "https://rest.isric.org/soilgrids/v2.0/properties/query"

# Properties to fetch
SOIL_PROPERTIES = [
    "phh2o",     # pH in H2O (×10 in API response)
    "soc",       # Soil Organic Carbon (g/kg ×10)
    "clay",      # Clay fraction (g/kg)
    "sand",      # Sand fraction (g/kg)
    "silt",      # Silt fraction (g/kg)
    "bdod",      # Bulk density (cg/cm³)
    "nitrogen",  # Nitrogen (cg/kg)
]

SOIL_DEPTHS = ["0-5cm", "5-15cm", "15-30cm"]  # top soil layers


@dataclass
class SoilData:
    """Parsed soil profile for a location."""
    latitude: float
    longitude: float
    soil_pH: float          # pH in H2O (actual, not ×10)
    organic_carbon_g_kg: float
    clay_pct: float
    sand_pct: float
    silt_pct: float
    bulk_density: float
    nitrogen_g_kg: float
    soil_type: str           # derived texture class
    source: str = "SOILGRIDS_V2"


def _derive_soil_type(sand: float, clay: float, silt: float) -> str:
    """
    USDA texture triangle classification (simplified).
    Inputs as percentages (0-100).
    """
    if clay >= 40:
        return "clay"
    elif clay >= 27 and silt >= 28:
        return "clay_loam"
    elif clay >= 35 and sand >= 45:
        return "sandy_clay"
    elif sand >= 70 and clay < 15:
        return "sandy_loam" if clay >= 7 else "sandy"
    elif silt >= 80:
        return "silt"
    elif silt >= 50 and clay < 27:
        return "silt_loam"
    elif clay >= 27 and sand < 20:
        return "silty_clay"
    else:
        return "loam"


async def fetch_soilgrids(
    latitude: float,
    longitude: float,
) -> SoilData:
    """
    Fetch soil data from SoilGrids REST API v2.0.

    Returns SoilData dataclass with averaged top-soil values.
    """
    params = {
        "lon": longitude,
        "lat": latitude,
        "property": SOIL_PROPERTIES,
        "depth": SOIL_DEPTHS,
        "value": "mean",
    }

    async with httpx.AsyncClient(timeout=18.0) as client:
        response = await client.get(
            SOILGRIDS_BASE,
            params=params,
        )
        response.raise_for_status()
        data = response.json()

    layers = data.get("properties", {}).get("layers", [])

    def _extract_mean(prop_name: str) -> float:
        """Extract the mean value across top soil depths for a given property."""
        values = []
        for layer in layers:
            if layer.get("name") == prop_name:
                for depth_data in layer.get("depths", []):
                    v = depth_data.get("values", {}).get("mean")
                    if v is not None and v != -9999:
                        values.append(float(v))
        return sum(values) / len(values) if values else 0.0

    # SoilGrids returns pH × 10, organic carbon ×10, fractions in g/kg
    ph_raw       = _extract_mean("phh2o")
    soc_raw      = _extract_mean("soc")
    clay_raw     = _extract_mean("clay")
    sand_raw     = _extract_mean("sand")
    silt_raw     = _extract_mean("silt")
    bdod_raw     = _extract_mean("bdod")
    nitrogen_raw = _extract_mean("nitrogen")

    # Convert units
    soil_pH      = ph_raw / 10.0 if ph_raw > 0 else 6.5
    soc_g_kg     = soc_raw / 10.0
    clay_pct     = clay_raw / 10.0  # g/kg → %
    sand_pct     = sand_raw / 10.0
    silt_pct     = silt_raw / 10.0
    bulk_density = bdod_raw / 100.0  # cg/cm³ → g/cm³
    nitrogen_g   = nitrogen_raw / 100.0

    soil_type = _derive_soil_type(sand_pct, clay_pct, silt_pct)

    return SoilData(
        latitude=latitude,
        longitude=longitude,
        soil_pH=round(soil_pH, 2),
        organic_carbon_g_kg=round(soc_g_kg, 2),
        clay_pct=round(clay_pct, 1),
        sand_pct=round(sand_pct, 1),
        silt_pct=round(silt_pct, 1),
        bulk_density=round(bulk_density, 3),
        nitrogen_g_kg=round(nitrogen_g, 2),
        soil_type=soil_type,
    )


def fetch_soil_sync(latitude: float, longitude: float) -> SoilData:
    """Synchronous wrapper for use outside async context."""
    return asyncio.run(fetch_soilgrids(latitude, longitude))


async def fetch_soil_with_fallback(
    latitude: float,
    longitude: float,
    fallback_pH: float = 6.5,
    fallback_soil_type: str = "loam",
) -> SoilData:
    """Fetch soil data; if API fails, return sensible fallback values."""
    try:
        return await fetch_soilgrids(latitude, longitude)
    except Exception as e:
        return SoilData(
            latitude=latitude,
            longitude=longitude,
            soil_pH=fallback_pH,
            organic_carbon_g_kg=10.0,
            clay_pct=25.0,
            sand_pct=40.0,
            silt_pct=35.0,
            bulk_density=1.3,
            nitrogen_g_kg=1.5,
            soil_type=fallback_soil_type,
            source=f"FALLBACK (SoilGrids error: {type(e).__name__})",
        )
