"""
image_analysis.py
=================
OpenCV + lightweight CNN for land photo analysis.

Extracts from the uploaded photo:
  1. Vegetation cover % (NDVI proxy from visible spectrum)
  2. Soil colour → rough texture class (red/dark/light)
  3. Waterlogging indicator (standing water detection via HSV masking)
  4. Land use class via MobileNetV2 transfer learning

Why OpenCV + CNN:
  - OpenCV handles classical colour-space operations cheaply on a server.
  - MobileNetV2 via TensorFlow Lite runs fast CPU inference, no GPU needed.
"""

from __future__ import annotations
import io
import numpy as np
from dataclasses import dataclass
from typing import Optional, Tuple
import cv2


@dataclass
class ImageAnalysisResult:
    """Results extracted from the land photo."""
    vegetation_cover_pct: float    # 0–100
    soil_color_class: str          # 'red', 'black', 'grey', 'brown', 'light'
    waterlogging_risk: str         # 'low', 'medium', 'high'
    estimated_ndvi_proxy: float    # 0–1 derived from visible channels
    lulc_class: str                # CNN-predicted land use / land cover
    confidence: float              # CNN confidence score 0–1
    image_quality: str             # 'good', 'poor_lighting', 'blurry'


# ---------------------------------------------------------------------------
# Classical CV pipeline
# ---------------------------------------------------------------------------

def _compute_excess_green(bgr: np.ndarray) -> np.ndarray:
    """
    Excess Green Index (ExG) — vegetation proxy from visible spectrum.
    ExG = 2G - R - B  (normalised to 0-255 range)
    """
    b, g, r = cv2.split(bgr.astype(np.float32))
    total = b + g + r + 1e-6
    # Normalise channels
    r_n = r / total
    g_n = g / total
    b_n = b / total
    exg = 2 * g_n - r_n - b_n
    # Scale to 0-255
    exg_scaled = np.clip((exg + 1) * 127.5, 0, 255).astype(np.uint8)
    return exg_scaled


def _detect_soil_color(bgr: np.ndarray) -> str:
    """
    Classify dominant soil colour using HSV histogram on non-vegetation pixels.
    Returns one of: 'red', 'black', 'brown', 'grey', 'light_yellow'
    """
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)

    # Sample soil pixels: low saturation or brownish hue
    soil_mask = (s < 80) | ((h > 8) & (h < 25) & (s > 30))
    if not np.any(soil_mask):
        return "brown"

    mean_h = float(np.mean(h[soil_mask]))
    mean_v = float(np.mean(v[soil_mask]))

    if mean_v < 60:
        return "black"   # dark/black cotton soil
    elif mean_h < 15 or mean_h > 165:
        return "red"     # red laterite
    elif mean_h < 30:
        return "brown"   # typical brown loam
    elif mean_v > 180:
        return "light_yellow"  # sandy / alkaline
    else:
        return "grey"


def _detect_waterlogging(bgr: np.ndarray) -> str:
    """
    Detect standing water via HSV blue-water masking.
    Returns 'low', 'medium', 'high'.
    """
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    # Water: hue 90-130, high saturation, moderate brightness
    lower_water = np.array([90, 50, 30])
    upper_water = np.array([130, 255, 200])
    water_mask = cv2.inRange(hsv, lower_water, upper_water)
    water_pct = float(np.sum(water_mask > 0)) / water_mask.size * 100

    if water_pct > 20:
        return "high"
    elif water_pct > 8:
        return "medium"
    else:
        return "low"


def _check_image_quality(bgr: np.ndarray) -> str:
    """Basic image quality checks."""
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    # Blurriness via Laplacian variance
    laplacian_var = float(cv2.Laplacian(gray, cv2.CV_64F).var())
    if laplacian_var < 30:
        return "blurry"
    mean_brightness = float(np.mean(gray))
    if mean_brightness < 30 or mean_brightness > 230:
        return "poor_lighting"
    return "good"


# ---------------------------------------------------------------------------
# CNN-based land use classification (MobileNetV2 via TensorFlow Lite)
# ---------------------------------------------------------------------------

# Land use classes for our fine-tuned model
LULC_CLASSES = [
    "agricultural_crop",
    "bare_soil",
    "flooded_field",
    "grassland",
    "plantation",
    "scrubland",
    "water_body",
    "built_up",
]


def _load_tflite_model():
    """Lazy-load TensorFlow Lite model from disk."""
    try:
        import tflite_runtime.interpreter as tflite
    except ImportError:
        try:
            import tensorflow.lite as tflite
        except ImportError:
            return None

    import os
    model_path = os.path.join(
        os.path.dirname(__file__), "..", "ml", "land_classifier.tflite"
    )
    if not os.path.exists(model_path):
        return None

    interpreter = tflite.Interpreter(model_path=model_path)
    interpreter.allocate_tensors()
    return interpreter


_tflite_interpreter = None  # cached globally


def _classify_with_cnn(bgr: np.ndarray) -> Tuple[str, float]:
    """
    Run MobileNetV2 TFLite inference on the image.
    Returns (class_label, confidence).
    Falls back to heuristic if model not loaded.
    """
    global _tflite_interpreter

    if _tflite_interpreter is None:
        _tflite_interpreter = _load_tflite_model()

    if _tflite_interpreter is not None:
        # Resize to MobileNetV2 input shape
        img = cv2.resize(bgr, (224, 224))
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = img.astype(np.float32) / 255.0
        img = np.expand_dims(img, axis=0)

        input_details = _tflite_interpreter.get_input_details()
        output_details = _tflite_interpreter.get_output_details()
        _tflite_interpreter.set_tensor(input_details[0]['index'], img)
        _tflite_interpreter.invoke()
        output = _tflite_interpreter.get_tensor(output_details[0]['index'])[0]

        top_idx = int(np.argmax(output))
        confidence = float(output[top_idx])
        if top_idx < len(LULC_CLASSES):
            return LULC_CLASSES[top_idx], confidence

    # Heuristic fallback based on colour analysis
    return "agricultural_crop", 0.6


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def analyse_land_image(image_bytes: bytes) -> ImageAnalysisResult:
    """
    Full pipeline: decode bytes → classical CV → CNN → result.

    Parameters
    ----------
    image_bytes : raw JPEG/PNG bytes from farmer's photo upload

    Returns
    -------
    ImageAnalysisResult
    """
    # Decode image
    np_arr = np.frombuffer(image_bytes, np.uint8)
    bgr = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

    if bgr is None:
        raise ValueError("Could not decode image. Ensure it is a valid JPEG or PNG.")

    # Resize for consistent processing (keep aspect, max 640px)
    h, w = bgr.shape[:2]
    if max(h, w) > 640:
        scale = 640 / max(h, w)
        bgr = cv2.resize(bgr, (int(w * scale), int(h * scale)))

    # ── Classical CV pipeline ───────────────────────────────────────────
    quality = _check_image_quality(bgr)

    exg = _compute_excess_green(bgr)
    _, veg_mask = cv2.threshold(exg, 120, 255, cv2.THRESH_BINARY)
    vegetation_pct = float(np.sum(veg_mask > 0)) / veg_mask.size * 100

    # NDVI proxy from ExG normalised
    ndvi_proxy = float(np.mean(exg)) / 255.0

    soil_color = _detect_soil_color(bgr)
    water_risk = _detect_waterlogging(bgr)

    # ── CNN classification ──────────────────────────────────────────────
    lulc_class, confidence = _classify_with_cnn(bgr)

    return ImageAnalysisResult(
        vegetation_cover_pct=round(vegetation_pct, 1),
        soil_color_class=soil_color,
        waterlogging_risk=water_risk,
        estimated_ndvi_proxy=round(ndvi_proxy, 3),
        lulc_class=lulc_class,
        confidence=round(confidence, 3),
        image_quality=quality,
    )
