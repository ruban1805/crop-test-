/**
 * api.js
 * ======
 * API client for the FastAPI backend.
 * Handles offline caching via AsyncStorage.
 * All calls degrade gracefully when offline.
 */

import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import NetInfo from '@react-native-community/netinfo';

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------
const BASE_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:8000';
const CACHE_TTL_MS = 6 * 60 * 60 * 1000; // 6 hours

const client = axios.create({
  baseURL: BASE_URL,
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
});

// ---------------------------------------------------------------------------
// Cache helpers
// ---------------------------------------------------------------------------

const cacheKey = (endpoint, params) =>
  `cache:${endpoint}:${JSON.stringify(params)}`;

async function getFromCache(key) {
  try {
    const raw = await AsyncStorage.getItem(key);
    if (!raw) return null;
    const { data, ts } = JSON.parse(raw);
    if (Date.now() - ts > CACHE_TTL_MS) return null; // expired
    return data;
  } catch {
    return null;
  }
}

async function saveToCache(key, data) {
  try {
    await AsyncStorage.setItem(key, JSON.stringify({ data, ts: Date.now() }));
  } catch {
    // Ignore write errors
  }
}

async function isOnline() {
  const state = await NetInfo.fetch();
  return state.isConnected && state.isInternetReachable;
}

// ---------------------------------------------------------------------------
// Core API calls
// ---------------------------------------------------------------------------

/**
 * POST /analyze-land
 * Sends land details + optional image.
 * Returns ranked crop recommendations.
 */
export async function analyzeLand({
  latitude,
  longitude,
  landSizeHa,
  waterSource,
  soilPH,
  soilType,
  language,
  topK = 5,
  useMlBlend = true,
  imageUri = null,
}) {
  const online = await isOnline();
  const key = cacheKey('/analyze-land', { latitude, longitude, soilPH, soilType });

  if (!online) {
    const cached = await getFromCache(key);
    if (cached) return { ...cached, _cached: true };
    throw new Error('offline_no_cache');
  }

  let response;

  if (imageUri) {
    // Multipart form data for image upload
    const formData = new FormData();
    formData.append('latitude', latitude);
    formData.append('longitude', longitude);
    formData.append('land_size_ha', landSizeHa);
    formData.append('water_source', waterSource);
    if (soilPH) formData.append('soil_p_h', soilPH);
    if (soilType) formData.append('soil_type', soilType);
    formData.append('language', language);
    formData.append('top_k', topK);
    formData.append('use_ml_blend', useMlBlend);
    formData.append('image', {
      uri: imageUri,
      type: 'image/jpeg',
      name: 'land_photo.jpg',
    });

    response = await axios.post(`${BASE_URL}/analyze-land`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      timeout: 60000, // longer timeout for image upload
    });
  } else {
    response = await client.post('/analyze-land', {
      latitude,
      longitude,
      land_size_ha: landSizeHa,
      water_source: waterSource,
      soil_p_h: soilPH || null,
      soil_type: soilType || null,
      language,
      top_k: topK,
      use_ml_blend: useMlBlend,
    });
  }

  await saveToCache(key, response.data);
  return response.data;
}

/**
 * GET /crops/search?q=<prefix>
 * Trie-based autocomplete.
 */
export async function searchCrops(prefix, maxResults = 10) {
  if (!prefix || prefix.length < 1) return [];
  try {
    const response = await client.get('/crops/search', {
      params: { q: prefix, max_results: maxResults },
    });
    return response.data.results || [];
  } catch {
    return [];
  }
}

/**
 * GET /crop/<name>
 * Detailed crop profile.
 */
export async function getCropDetail(cropName) {
  const key = cacheKey('/crop', { cropName });
  const cached = await getFromCache(key);
  if (cached) return cached;

  const response = await client.get(`/crop/${encodeURIComponent(cropName)}`);
  await saveToCache(key, response.data);
  return response.data;
}

/**
 * GET /crops
 * List all crops.
 */
export async function listAllCrops() {
  const key = cacheKey('/crops', {});
  const cached = await getFromCache(key);
  if (cached) return cached;

  const response = await client.get('/crops');
  await saveToCache(key, response.data);
  return response.data;
}

/**
 * Save the last analysis result for offline access.
 */
export async function saveLastResult(data) {
  await AsyncStorage.setItem('last_result', JSON.stringify(data));
}

/**
 * Load the last saved analysis result.
 */
export async function loadLastResult() {
  const raw = await AsyncStorage.getItem('last_result');
  return raw ? JSON.parse(raw) : null;
}
