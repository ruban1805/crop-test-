/**
 * TrieSearch.js
 * =============
 * DATA STRUCTURE: Trie (client-side)
 * WHY: Offline-first autocomplete that works without network.
 *      Seeded with the crop database on app launch.
 *      O(L) prefix search where L = query length.
 */

class TrieNode {
  constructor() {
    this.children = {};
    this.isEnd = false;
    this.fullWord = null;
  }
}

class Trie {
  constructor() {
    this.root = new TrieNode();
    this.count = 0;
  }

  _normalize(word) {
    return word.toLowerCase().replace(/\s+/g, '_');
  }

  insert(word) {
    const key = this._normalize(word);
    let node = this.root;
    for (const char of key) {
      if (!node.children[char]) {
        node.children[char] = new TrieNode();
      }
      node = node.children[char];
    }
    if (!node.isEnd) {
      node.isEnd = true;
      node.fullWord = word;
      this.count++;
    }
  }

  search(word) {
    const node = this._findNode(this._normalize(word));
    return node !== null && node.isEnd;
  }

  autocomplete(prefix, maxResults = 10) {
    const node = this._findNode(this._normalize(prefix));
    if (!node) return [];
    const results = [];
    this._dfs(node, results, maxResults);
    return results;
  }

  _findNode(key) {
    let node = this.root;
    for (const char of key) {
      if (!node.children[char]) return null;
      node = node.children[char];
    }
    return node;
  }

  _dfs(node, results, max) {
    if (results.length >= max) return;
    if (node.isEnd && node.fullWord) results.push(node.fullWord);
    for (const child of Object.values(node.children)) {
      if (results.length >= max) return;
      this._dfs(child, results, max);
    }
  }
}

// ---------------------------------------------------------------------------
// Singleton loaded with default crop list
// ---------------------------------------------------------------------------

const DEFAULT_CROPS = [
  'paddy', 'maize', 'sorghum', 'pearl millet', 'finger millet',
  'groundnut', 'sesame', 'castor', 'blackgram', 'greengram',
  'cowpea', 'sugarcane', 'cotton', 'banana', 'turmeric',
  'onion', 'tomato', 'sunflower', 'tapioca',
];

const cropTrie = new Trie();
DEFAULT_CROPS.forEach(name => {
  cropTrie.insert(name);
  // Also insert title case
  cropTrie.insert(name.replace(/\b\w/g, c => c.toUpperCase()));
});

/**
 * Refresh the trie with server-fetched crop names.
 * Call this after a successful /crops API response.
 */
export function refreshCropTrie(cropNames) {
  for (const name of cropNames) {
    cropTrie.insert(name);
    cropTrie.insert(name.replace(/\b\w/g, c => c.toUpperCase()));
  }
}

/**
 * Autocomplete search — falls back to local trie if offline.
 */
export function localAutocomplete(prefix, maxResults = 10) {
  return cropTrie.autocomplete(prefix, maxResults);
}

export default Trie;
