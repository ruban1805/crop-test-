/**
 * translations.js
 * ===============
 * English + Tamil UI strings.
 * Add a new key to BOTH en and ta objects to keep them in sync.
 */

export const translations = {
  en: {
    // ── App general ──────────────────────────────────────
    appName: "Crop DSS",
    appTagline: "Smart crop recommendations for your land",
    language: "Language",
    english: "English",
    tamil: "Tamil",

    // ── Home screen ──────────────────────────────────────
    homeTitle: "Crop Decision Support",
    homeSubtitle: "Tell us about your land — we'll tell you what to grow.",
    startAnalysis: "Start Analysis",
    viewHistory: "View History",

    // ── Input form ───────────────────────────────────────
    locationLabel: "Location",
    detectLocation: "Detect my location",
    orPinOnMap: "or pin on map",
    landSizeLabel: "Land size (hectares)",
    landSizePlaceholder: "e.g. 2.5",
    waterSourceLabel: "Water source",
    waterRainFed: "Rain-fed",
    waterIrrigated: "Canal / Irrigated",
    waterWell: "Borewell / Well",
    soilPHLabel: "Soil pH (optional)",
    soilPHPlaceholder: "e.g. 6.5  (leave blank to auto-detect)",
    soilTypeLabel: "Soil type (optional)",
    uploadPhotoLabel: "Upload land photo (optional)",
    uploadPhotoButton: "Choose Photo",
    takePhotoButton: "Take Photo",
    analyzeButton: "Analyze My Land",
    analyzing: "Analyzing…",

    // ── Results screen ───────────────────────────────────
    resultsTitle: "Crop Recommendations",
    suitabilityLabel: "Suitability",
    topReasonsLabel: "Why this crop?",
    yieldRangeLabel: "Expected yield",
    sowingWindowLabel: "Best sowing window",
    marketPriceLabel: "Market price",
    viewDetails: "View details",
    rank: "Rank",
    perKg: "per kg",
    perHa: "per hectare",

    // ── Detail screen ────────────────────────────────────
    detailTitle: "Crop Details",
    criteriaBreakdown: "Score Breakdown",
    soilFit: "Soil compatibility",
    waterFit: "Water availability",
    tempFit: "Temperature suitability",
    rainfallFit: "Rainfall adequacy",
    marketDemand: "Market attractiveness",
    expectedYield: "Yield potential",
    season: "Season",
    duration: "Duration",
    days: "days",
    mlBlend: "ML yield model blended",

    // ── Weather / Soil info ──────────────────────────────
    weatherTitle: "Weather Data",
    soilTitle: "Soil Data",
    annualRainfall: "Annual Rainfall",
    avgTemperature: "Avg Temperature",
    soilPH: "Soil pH",
    soilType: "Soil Type",
    ndvi: "Vegetation Index (NDVI)",
    dataSource: "Data source",
    mm: "mm",
    celsius: "°C",

    // ── Error / Status ───────────────────────────────────
    errorGeneral: "Something went wrong. Please try again.",
    errorLocation: "Could not detect location. Please pin it manually.",
    errorNoInternet: "No internet connection. Showing cached results.",
    noResultsTitle: "No Suitable Crops Found",
    noResultsMessage: "The constraints you've entered are very restrictive. Try adjusting soil pH or water source.",
    loading: "Loading…",
    retry: "Retry",
    cached: "Showing cached results",

    // ── Search / Trie ────────────────────────────────────
    searchCrops: "Search crops…",
    searchPlaceholder: "Type crop name…",
  },

  ta: {
    // ── App general ──────────────────────────────────────
    appName: "பயிர் DSS",
    appTagline: "உங்கள் நிலத்திற்கான அறிவார்ந்த பயிர் பரிந்துரைகள்",
    language: "மொழி",
    english: "ஆங்கிலம்",
    tamil: "தமிழ்",

    // ── Home screen ──────────────────────────────────────
    homeTitle: "பயிர் முடிவு ஆதரவு",
    homeSubtitle: "உங்கள் நிலம் பற்றி கூறுங்கள் — என்ன பயிர் செய்யலாம் என்று சொல்கிறோம்.",
    startAnalysis: "பகுப்பாய்வு தொடங்கு",
    viewHistory: "வரலாறு காண்",

    // ── Input form ───────────────────────────────────────
    locationLabel: "இடம்",
    detectLocation: "என் இருப்பிடத்தை கண்டறி",
    orPinOnMap: "அல்லது வரைபடத்தில் குறி",
    landSizeLabel: "நில அளவு (ஹெக்டேர்)",
    landSizePlaceholder: "எ.கா. 2.5",
    waterSourceLabel: "நீர் ஆதாரம்",
    waterRainFed: "மழை நீர்",
    waterIrrigated: "கால்வாய் / பாசனம்",
    waterWell: "குழாய் கிணறு / கிணறு",
    soilPHLabel: "மண் pH (விரும்பினால்)",
    soilPHPlaceholder: "எ.கா. 6.5 (தானாக கண்டறிய காலி விடுங்கள்)",
    soilTypeLabel: "மண் வகை (விரும்பினால்)",
    uploadPhotoLabel: "நில புகைப்படம் பதிவேற்று (விரும்பினால்)",
    uploadPhotoButton: "புகைப்படம் தேர்ந்தெடு",
    takePhotoButton: "புகைப்படம் எடு",
    analyzeButton: "என் நிலத்தை பகுப்பாய்வு செய்",
    analyzing: "பகுப்பாய்வு செய்கிறது…",

    // ── Results screen ───────────────────────────────────
    resultsTitle: "பயிர் பரிந்துரைகள்",
    suitabilityLabel: "பொருத்தம்",
    topReasonsLabel: "இந்த பயிர் ஏன்?",
    yieldRangeLabel: "எதிர்பார்க்கப்படும் மகசூல்",
    sowingWindowLabel: "சிறந்த விதைப்பு காலம்",
    marketPriceLabel: "சந்தை விலை",
    viewDetails: "விவரங்கள் காண்",
    rank: "தரவரிசை",
    perKg: "கிலோவுக்கு",
    perHa: "ஹெக்டேருக்கு",

    // ── Detail screen ────────────────────────────────────
    detailTitle: "பயிர் விவரங்கள்",
    criteriaBreakdown: "மதிப்பெண் பகுப்பு",
    soilFit: "மண் பொருத்தம்",
    waterFit: "நீர் கிடைக்கும் தன்மை",
    tempFit: "வெப்பநிலை ஏற்புடைமை",
    rainfallFit: "மழை போதுமானது",
    marketDemand: "சந்தை கவர்ச்சி",
    expectedYield: "மகசூல் திறன்",
    season: "பருவம்",
    duration: "கால அளவு",
    days: "நாட்கள்",
    mlBlend: "ML மகசூல் மாதிரி கலக்கப்பட்டது",

    // ── Weather / Soil info ──────────────────────────────
    weatherTitle: "வானிலை தரவு",
    soilTitle: "மண் தரவு",
    annualRainfall: "ஆண்டு மழையளவு",
    avgTemperature: "சராசரி வெப்பநிலை",
    soilPH: "மண் pH",
    soilType: "மண் வகை",
    ndvi: "தாவர குறியீடு (NDVI)",
    dataSource: "தரவு ஆதாரம்",
    mm: "மிமீ",
    celsius: "°C",

    // ── Error / Status ───────────────────────────────────
    errorGeneral: "ஏதோ தவறு நடந்தது. மீண்டும் முயற்சிக்கவும்.",
    errorLocation: "இருப்பிடத்தை கண்டறிய முடியவில்லை. கைமுறையாக குறியிடவும்.",
    errorNoInternet: "இணைய இணைப்பு இல்லை. தற்காலிக முடிவுகள் காட்டப்படுகின்றன.",
    noResultsTitle: "ஏற்ற பயிர்கள் இல்லை",
    noResultsMessage: "நீங்கள் உள்ளிட்ட நிபந்தனைகள் மிகவும் கட்டுப்பாடானவை. மண் pH அல்லது நீர் ஆதாரத்தை சரிசெய்யவும்.",
    loading: "ஏற்றுகிறது…",
    retry: "மீண்டும் முயற்சி",
    cached: "தற்காலிக முடிவுகள் காட்டப்படுகின்றன",

    // ── Search / Trie ────────────────────────────────────
    searchCrops: "பயிர்களை தேடு…",
    searchPlaceholder: "பயிர் பெயர் தட்டச்சு செய்…",
  },
};

export const getTranslation = (lang, key) => {
  const t = translations[lang] || translations.en;
  return t[key] || translations.en[key] || key;
};
