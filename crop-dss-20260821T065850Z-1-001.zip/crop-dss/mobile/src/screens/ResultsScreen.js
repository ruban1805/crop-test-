/**
 * ResultsScreen.js
 * ================
 * Displays ranked crop recommendations from the MCDM engine.
 * Each card shows suitability %, top reasons, yield, sowing window.
 */

import React, { useContext } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, FlatList,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getTranslation } from '../i18n/translations';
import { LanguageContext } from '../../App';

const BRAND = '#2D6A4F';
const COLORS = ['#40916C', '#52B788', '#74C69D', '#95D5B2', '#B7E4C7'];

// Circular percentage arc component (pure RN, no SVG dep)
function SuitabilityBadge({ percent }) {
  const color = percent >= 75 ? '#40916C' : percent >= 50 ? '#F59E0B' : '#EF4444';
  return (
    <View style={[badgeStyles.container, { borderColor: color }]}>
      <Text style={[badgeStyles.pct, { color }]}>{Math.round(percent)}%</Text>
    </View>
  );
}
const badgeStyles = StyleSheet.create({
  container: {
    width: 64, height: 64, borderRadius: 32,
    borderWidth: 4, alignItems: 'center', justifyContent: 'center',
  },
  pct: { fontSize: 16, fontWeight: 'bold' },
});

function CropCard({ item, rank, lang, onPress }) {
  const t = (k) => getTranslation(lang, k);
  const rankColor = COLORS[rank - 1] || COLORS[4];

  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.85}>
      {/* Rank badge */}
      <View style={[styles.rankBadge, { backgroundColor: rankColor }]}>
        <Text style={styles.rankText}>#{rank}</Text>
      </View>

      <View style={styles.cardTop}>
        <View style={{ flex: 1 }}>
          <Text style={styles.cropName}>
            {item.crop_name.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}
          </Text>
          <Text style={styles.season}>{item.season} · {item.duration_days} {t('days')}</Text>
        </View>
        <SuitabilityBadge percent={item.suitability_percent} />
      </View>

      {/* Top reasons */}
      <View style={styles.reasonsBox}>
        <Text style={styles.sectionLabel}>{t('topReasonsLabel')}</Text>
        {item.top_reasons.map((r, i) => (
          <View key={i} style={styles.reasonRow}>
            <Ionicons name="checkmark-circle" size={14} color={BRAND} />
            <Text style={styles.reasonText}>{r}</Text>
          </View>
        ))}
      </View>

      {/* Quick stats */}
      <View style={styles.statsRow}>
        <View style={styles.stat}>
          <Ionicons name="trending-up-outline" size={14} color="#6B7280" />
          <Text style={styles.statLabel}>{t('yieldRangeLabel')}</Text>
          <Text style={styles.statValue}>{item.expected_yield_range}</Text>
        </View>
        <View style={styles.stat}>
          <Ionicons name="pricetag-outline" size={14} color="#6B7280" />
          <Text style={styles.statLabel}>{t('marketPriceLabel')}</Text>
          <Text style={styles.statValue}>₹{item.market_price_per_kg}/{t('perKg')}</Text>
        </View>
      </View>

      <Text style={styles.sowingWindow}>
        🗓 {item.best_sowing_window}
      </Text>

      <Text style={styles.detailLink}>{t('viewDetails')} →</Text>
    </TouchableOpacity>
  );
}

export default function ResultsScreen({ route, navigation }) {
  const { result } = route.params;
  const { lang } = useContext(LanguageContext);
  const t = (k) => getTranslation(lang, k);

  const recs = result.recommendations || [];
  const weather = result.weather || {};
  const soil = result.soil || {};

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>

      {/* ── Summary bar ── */}
      <View style={styles.summaryBar}>
        <View style={styles.summaryItem}>
          <Ionicons name="rainy-outline" size={18} color="#fff" />
          <Text style={styles.summaryLabel}>{t('annualRainfall')}</Text>
          <Text style={styles.summaryValue}>{weather.annual_rainfall_mm?.toFixed(0)} {t('mm')}</Text>
        </View>
        <View style={styles.summaryItem}>
          <Ionicons name="thermometer-outline" size={18} color="#fff" />
          <Text style={styles.summaryLabel}>{t('avgTemperature')}</Text>
          <Text style={styles.summaryValue}>{weather.avg_temp_C?.toFixed(1)}{t('celsius')}</Text>
        </View>
        <View style={styles.summaryItem}>
          <Ionicons name="flask-outline" size={18} color="#fff" />
          <Text style={styles.summaryLabel}>{t('soilPH')}</Text>
          <Text style={styles.summaryValue}>{soil.soil_pH}</Text>
        </View>
      </View>

      {/* ── Cached indicator ── */}
      {result._cached && (
        <View style={styles.cacheBanner}>
          <Ionicons name="cloud-offline-outline" size={14} color="#92400E" />
          <Text style={styles.cacheText}>{t('cached')}</Text>
        </View>
      )}

      {/* ── Recommendation list ── */}
      <Text style={styles.sectionTitle}>{t('resultsTitle')}</Text>
      <Text style={styles.subtitle}>
        {recs.length} crops recommended · {result.eliminated_count} eliminated
      </Text>

      {recs.length === 0 ? (
        <View style={styles.emptyCard}>
          <Ionicons name="sad-outline" size={48} color="#9CA3AF" />
          <Text style={styles.emptyTitle}>{t('noResultsTitle')}</Text>
          <Text style={styles.emptyMsg}>{t('noResultsMessage')}</Text>
        </View>
      ) : (
        recs.map((item) => (
          <CropCard
            key={item.crop_name}
            item={item}
            rank={item.rank}
            lang={lang}
            onPress={() =>
              navigation.navigate('Detail', { crop: item, lang, soilData: soil, weatherData: weather })
            }
          />
        ))
      )}

      {/* ── AHP weights footer ── */}
      {result.ahp_weights && Object.keys(result.ahp_weights).length > 0 && (
        <View style={styles.ahpCard}>
          <Text style={styles.ahpTitle}>AHP Weights (CR={result.ahp_cr?.toFixed(3)})</Text>
          {Object.entries(result.ahp_weights).map(([k, v]) => (
            <View key={k} style={styles.ahpRow}>
              <Text style={styles.ahpLabel}>{k.replace(/_/g, ' ')}</Text>
              <View style={styles.ahpBarBg}>
                <View style={[styles.ahpBar, { width: `${(v * 100).toFixed(0)}%` }]} />
              </View>
              <Text style={styles.ahpPct}>{(v * 100).toFixed(1)}%</Text>
            </View>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F1F8F5' },
  content: { padding: 16, paddingBottom: 40 },

  summaryBar: {
    flexDirection: 'row', backgroundColor: BRAND,
    borderRadius: 10, padding: 12, marginBottom: 14,
    justifyContent: 'space-around',
  },
  summaryItem: { alignItems: 'center' },
  summaryLabel: { color: '#B7E4C7', fontSize: 10, marginTop: 2 },
  summaryValue: { color: '#fff', fontWeight: 'bold', fontSize: 13 },

  cacheBanner: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#FEF3C7', borderRadius: 6,
    paddingHorizontal: 10, paddingVertical: 6,
    marginBottom: 10,
  },
  cacheText: { color: '#92400E', fontSize: 12, marginLeft: 6 },

  sectionTitle: { fontSize: 20, fontWeight: 'bold', color: '#1F2937', marginBottom: 2 },
  subtitle: { fontSize: 12, color: '#6B7280', marginBottom: 14 },

  card: {
    backgroundColor: '#fff', borderRadius: 12,
    padding: 16, marginBottom: 14,
    shadowColor: '#000', shadowOpacity: 0.07,
    shadowRadius: 8, elevation: 3,
  },
  cardTop: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  rankBadge: {
    position: 'absolute', top: -16, right: -16,
    width: 32, height: 32, borderRadius: 16,
    alignItems: 'center', justifyContent: 'center',
  },
  rankText: { color: '#fff', fontWeight: 'bold', fontSize: 12 },
  cropName: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  season: { fontSize: 12, color: '#6B7280', marginTop: 2 },

  reasonsBox: {
    backgroundColor: '#F0FFF4', borderRadius: 8,
    padding: 10, marginBottom: 10,
  },
  sectionLabel: { fontSize: 11, fontWeight: '700', color: BRAND, marginBottom: 4 },
  reasonRow: { flexDirection: 'row', alignItems: 'flex-start', marginTop: 3 },
  reasonText: { fontSize: 12, color: '#374151', marginLeft: 6, flex: 1 },

  statsRow: { flexDirection: 'row', marginBottom: 8 },
  stat: { flex: 1, alignItems: 'center' },
  statLabel: { fontSize: 10, color: '#9CA3AF', marginTop: 2 },
  statValue: { fontSize: 13, fontWeight: '600', color: '#1F2937', textAlign: 'center' },

  sowingWindow: { fontSize: 12, color: '#374151', marginBottom: 6 },
  detailLink: { fontSize: 12, color: BRAND, fontWeight: '700', textAlign: 'right' },

  emptyCard: {
    alignItems: 'center', padding: 40,
    backgroundColor: '#fff', borderRadius: 12,
  },
  emptyTitle: { fontSize: 18, fontWeight: 'bold', color: '#374151', marginTop: 12 },
  emptyMsg: { fontSize: 13, color: '#6B7280', textAlign: 'center', marginTop: 8 },

  ahpCard: {
    backgroundColor: '#fff', borderRadius: 10,
    padding: 14, marginTop: 4,
    shadowColor: '#000', shadowOpacity: 0.04,
    shadowRadius: 4, elevation: 1,
  },
  ahpTitle: { fontSize: 12, fontWeight: '700', color: '#374151', marginBottom: 8 },
  ahpRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 4 },
  ahpLabel: { width: 120, fontSize: 11, color: '#6B7280' },
  ahpBarBg: { flex: 1, height: 6, backgroundColor: '#E5E7EB', borderRadius: 3, marginHorizontal: 8 },
  ahpBar: { height: 6, backgroundColor: BRAND, borderRadius: 3 },
  ahpPct: { width: 36, fontSize: 10, color: '#374151', textAlign: 'right' },
});
