/**
 * SearchScreen.js
 * ===============
 * Crop search using the Trie (client-side autocomplete) + server detail fetch.
 */

import React, { useState, useCallback, useContext } from 'react';
import {
  View, Text, TextInput, FlatList,
  TouchableOpacity, StyleSheet, ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getTranslation } from '../i18n/translations';
import { LanguageContext } from '../../App';
import { localAutocomplete } from '../utils/TrieSearch';
import { searchCrops } from '../utils/api';

const BRAND = '#2D6A4F';

export default function SearchScreen({ navigation }) {
  const { lang } = useContext(LanguageContext);
  const t = (k) => getTranslation(lang, k);

  const [query, setQuery]       = useState('');
  const [results, setResults]   = useState([]);
  const [loading, setLoading]   = useState(false);

  const handleSearch = useCallback(async (text) => {
    setQuery(text);
    if (text.length === 0) {
      setResults([]);
      return;
    }

    // 1. Instant local Trie results (O(L) — shown immediately)
    const local = localAutocomplete(text, 10);
    setResults(local);

    // 2. Server results in background (may include newer DB entries)
    setLoading(true);
    try {
      const server = await searchCrops(text, 10);
      if (server.length > 0) {
        // Merge, deduplicate, keep order
        const merged = [...new Set([...server, ...local])];
        setResults(merged);
      }
    } catch {
      // Use local results only
    } finally {
      setLoading(false);
    }
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.searchBar}>
        <Ionicons name="search" size={18} color="#9CA3AF" />
        <TextInput
          style={styles.input}
          placeholder={t('searchPlaceholder')}
          value={query}
          onChangeText={handleSearch}
          autoFocus
          returnKeyType="search"
        />
        {loading && <ActivityIndicator size="small" color={BRAND} />}
        {query.length > 0 && (
          <TouchableOpacity onPress={() => { setQuery(''); setResults([]); }}>
            <Ionicons name="close-circle" size={18} color="#9CA3AF" />
          </TouchableOpacity>
        )}
      </View>

      <FlatList
        data={results}
        keyExtractor={(item) => item}
        contentContainerStyle={{ padding: 16 }}
        ListEmptyComponent={
          query.length > 0 ? (
            <Text style={styles.empty}>No crops found for "{query}"</Text>
          ) : (
            <Text style={styles.hint}>Start typing a crop name…</Text>
          )
        }
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.resultItem}
            onPress={() => navigation.navigate('CropDetail', { cropName: item })}
          >
            <Ionicons name="leaf-outline" size={18} color={BRAND} />
            <Text style={styles.resultText}>
              {item.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}
            </Text>
            <Ionicons name="chevron-forward" size={16} color="#9CA3AF" />
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F1F8F5' },
  searchBar: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#fff', margin: 12,
    borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8,
    shadowColor: '#000', shadowOpacity: 0.06, elevation: 2,
  },
  input: { flex: 1, marginLeft: 8, fontSize: 15, color: '#1F2937' },
  resultItem: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#fff', borderRadius: 8,
    padding: 14, marginBottom: 8,
    shadowColor: '#000', shadowOpacity: 0.04, elevation: 1,
  },
  resultText: { flex: 1, marginLeft: 10, fontSize: 15, color: '#1F2937' },
  empty: { textAlign: 'center', color: '#9CA3AF', marginTop: 40 },
  hint: { textAlign: 'center', color: '#9CA3AF', marginTop: 40 },
});
