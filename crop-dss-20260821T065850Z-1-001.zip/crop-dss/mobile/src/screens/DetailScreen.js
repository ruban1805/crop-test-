/**
 * DetailScreen.js
 * ===============
 * Full breakdown for a single crop:
 *  - TOPSIS per-criterion scores as horizontal bars
 *  - Top reasons and worst factors
 *  - Soil, weather, ML blend indicator
 */

import React, { useContext } from 'react';
import {
  View, Text, ScrollView, StyleSheet,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getTranslation } from '../i18n/translations';
import { LanguageContext } from '../../App';

const BRAND = '#2D6A4F';

const CRITERION_ICONS = {
  soil_fit:       'layers-outline',
  water_fit:      'water-outline',
  temp_fit:       'thermometer-outline',
  rainfall_fit:   'rainy-outline',
  market_demand:  'pricetag-outline',
  expected_yield: 'trending-up-outline',
};

function ScoreBar({ label, score, icon }) {
  const pct = Math.min(100, Math.round(score * 10000) / 100);
  const color = pct >= 70 ? '#40916C' : pct >= 40 ? '#F59E0B' : '#EF4444';
  return (
    <View style={styles.scoreRow}>
      <Ionicons name={icon} size={16} color="#6B7280" style={{ width: 22 }} />
      <Text style={styles.scoreLabel}>{label}</Text>
      <View style={styles.barBg}>
        <View style={[styles.barFill, { width: `${pct}%`, backgroundColor: color }]} />
      </View>
      <Text style={[styles.scorePct, { color }]}>{pct.toFixed(1)}%</Text>
    </View>
  );
}

export default function DetailScreen({ route }) {
  const { crop, soilData, weatherData } = route.params;
  const { lang } = useContext(LanguageContext);
  const t = (k) => getTranslation(lang, k);

  const cropDisplayName = crop.crop_name
    .replace(/_/g, ' ')
    .replace(/\b\w/g, c => c.toUpperCase());

  const topsisEntries = Object.entries(crop.topsis_scores || {});

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>

      {/* ── Header ── */}
      <View style={styles.header}>
        <Text style={styles.cropTitle}>{cropDisplayName}</Text>
        <View style={styles.pctCircle}>
          <Text style={styles.pctText}>{Math.round(crop.suitability_percent)}%</Text>
          <Text style={styles.pctSub}>{t('suitabilityLabel')}</Text>
        </View>
      </View>

      {/* ── Quick Facts ── */}
      <View style={styles.factsRow}>
        {[
          { icon: 'calendar-outline',   label: t('season'),   val: crop.season },
          { icon: 'hourglass-outline',  label: t('duration'), val: `${crop.duration_days} ${t('days')}` },
          { icon: 'pricetag-outline',   label: t('marketPriceLabel'), val: `₹${crop.market_price_per_kg}/kg` },
        ].map(({ icon, label, val }) => (
          <View key={label} style={styles.factCard}>
            <Ionicons name={icon} size={20} color={BRAND} />
            <Text style={styles.factLabel}>{label}</Text>
            <Text style={styles.factVal}>{val}</Text>
          </View>
        ))}
      </View>

      {/* ── Sowing window ── */}
      <View style={styles.sowingCard}>
        <Ionicons name="sunny-outline" size={18} color={BRAND} />
        <View style={{ marginLeft: 10 }}>
          <Text style={styles.sowingLabel}>{t('sowingWindowLabel')}</Text>
          <Text style={styles.sowingVal}>{crop.best_sowing_window}</Text>
        </View>
      </View>

      {/* ── Yield range ── */}
      <View style={styles.yieldCard}>
        <Ionicons name="trending-up-outline" size={18} color={BRAND} />
        <View style={{ marginLeft: 10 }}>
          <Text style={styles.sowingLabel}>{t('yieldRangeLabel')}</Text>
          <Text style={styles.sowingVal}>{crop.expected_yield_range}</Text>
        </View>
      </View>

      {/* ── TOPSIS Score Breakdown ── */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>{t('criteriaBreakdown')}</Text>
        {topsisEntries.map(([crit, score]) => (
          <ScoreBar
            key={crit}
            label={t(crit.replace('_fit', 'Fit').replace('_', '')
              .replace('soil', 'soilFit')
              .replace('water', 'waterFit')
              .replace('temp', 'tempFit')
              .replace('rainfall', 'rainfallFit')
              .replace('market', 'marketDemand')
              .replace('expected', 'expectedYield')
            ) || crit.replace(/_/g, ' ')}
            score={score}
            icon={CRITERION_ICONS[crit] || 'stats-chart-outline'}
          />
        ))}
      </View>

      {/* ── Why this crop ── */}
      {crop.top_reasons?.length > 0 && (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>{t('topReasonsLabel')}</Text>
          {crop.top_reasons.map((r, i) => (
            <View key={i} style={styles.reasonRow}>
              <Ionicons name="checkmark-circle" size={16} color={BRAND} />
              <Text style={styles.reasonText}>{r}</Text>
            </View>
          ))}
        </View>
      )}

      {/* ── Weak factors ── */}
      {crop.worst_factors?.length > 0 && (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Limiting factors</Text>
          {crop.worst_factors.map((f, i) => (
            <View key={i} style={styles.reasonRow}>
              <Ionicons name="alert-circle-outline" size={16} color="#F59E0B" />
              <Text style={styles.reasonText}>{f}</Text>
            </View>
          ))}
        </View>
      )}

      {/* ── ML badge ── */}
      {crop.ml_blend_applied && (
        <View style={styles.mlBadge}>
          <Ionicons name="hardware-chip-outline" size={14} color="#1D4ED8" />
          <Text style={styles.mlText}>
            {t('mlBlend')} — ML score: {(crop.ml_yield_score * 100)?.toFixed(1)}%
          </Text>
        </View>
      )}

      {/* ── Context data ── */}
      {soilData && (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>{t('soilTitle')}</Text>
          {[
            ['soil_pH',  t('soilPH'),   soilData.soil_pH],
            ['soil_type', t('soilType'), soilData.soil_type],
            ['clay_pct',  'Clay %',      soilData.clay_pct],
            ['sand_pct',  'Sand %',      soilData.sand_pct],
          ].filter(([, , v]) => v !== undefined).map(([, label, val]) => (
            <View key={label} style={styles.infoRow}>
              <Text style={styles.infoLabel}>{label}</Text>
              <Text style={styles.infoVal}>{val}</Text>
            </View>
          ))}
        </View>
      )}

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F1F8F5' },
  content: { padding: 16, paddingBottom: 40 },

  header: {
    flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: BRAND, borderRadius: 12,
    padding: 20, marginBottom: 14,
  },
  cropTitle: { fontSize: 22, fontWeight: 'bold', color: '#fff', flex: 1 },
  pctCircle: {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center', justifyContent: 'center',
  },
  pctText: { color: '#fff', fontSize: 20, fontWeight: 'bold' },
  pctSub: { color: '#B7E4C7', fontSize: 9 },

  factsRow: { flexDirection: 'row', marginBottom: 10 },
  factCard: {
    flex: 1, alignItems: 'center', backgroundColor: '#fff',
    borderRadius: 10, padding: 12, marginHorizontal: 4,
    shadowColor: '#000', shadowOpacity: 0.05, elevation: 2,
  },
  factLabel: { fontSize: 10, color: '#9CA3AF', marginTop: 4 },
  factVal: { fontSize: 12, fontWeight: '700', color: '#1F2937', textAlign: 'center' },

  sowingCard: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#ECFDF5', borderRadius: 10,
    padding: 14, marginBottom: 8,
  },
  yieldCard: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#FFF7ED', borderRadius: 10,
    padding: 14, marginBottom: 10,
  },
  sowingLabel: { fontSize: 10, color: '#6B7280' },
  sowingVal: { fontSize: 14, fontWeight: '600', color: '#1F2937', marginTop: 2 },

  card: {
    backgroundColor: '#fff', borderRadius: 10,
    padding: 14, marginBottom: 12,
    shadowColor: '#000', shadowOpacity: 0.05, elevation: 2,
  },
  cardTitle: { fontSize: 14, fontWeight: '700', color: '#1F2937', marginBottom: 10 },

  scoreRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  scoreLabel: { fontSize: 12, color: '#374151', width: 130 },
  barBg: { flex: 1, height: 8, backgroundColor: '#E5E7EB', borderRadius: 4, marginHorizontal: 8 },
  barFill: { height: 8, borderRadius: 4 },
  scorePct: { fontSize: 11, fontWeight: '600', width: 40, textAlign: 'right' },

  reasonRow: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 6 },
  reasonText: { fontSize: 13, color: '#374151', marginLeft: 8, flex: 1 },

  mlBadge: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#EFF6FF', borderRadius: 8,
    padding: 10, marginBottom: 10,
  },
  mlText: { color: '#1D4ED8', fontSize: 12, marginLeft: 6 },

  infoRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  infoLabel: { fontSize: 12, color: '#6B7280' },
  infoVal: { fontSize: 12, fontWeight: '600', color: '#1F2937' },
});
