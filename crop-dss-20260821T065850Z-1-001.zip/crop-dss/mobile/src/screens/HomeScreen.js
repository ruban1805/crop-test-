/**
 * HomeScreen.js
 * =============
 * Landing screen: location input, land details form, photo upload, and
 * language toggle. Submits to the backend and navigates to Results.
 */

import React, { useState, useEffect, useContext } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, ScrollView,
  StyleSheet, Alert, Image, ActivityIndicator, Switch,
} from 'react-native';
import * as Location from 'expo-location';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { getTranslation } from '../i18n/translations';
import { LanguageContext } from '../../App';
import { analyzeLand, saveLastResult } from '../utils/api';

const WATER_SOURCES = ['rain_fed', 'irrigated', 'well'];
const WATER_SOURCE_LABELS = {
  rain_fed:   { en: 'Rain-fed',           ta: 'மழை நீர்' },
  irrigated:  { en: 'Canal / Irrigated',  ta: 'கால்வாய் / பாசனம்' },
  well:       { en: 'Borewell / Well',    ta: 'குழாய் கிணறு' },
};

export default function HomeScreen({ navigation }) {
  const { lang, setLang } = useContext(LanguageContext);
  const t = (key) => getTranslation(lang, key);

  const [latitude, setLatitude]     = useState('');
  const [longitude, setLongitude]   = useState('');
  const [landSize, setLandSize]     = useState('');
  const [waterSource, setWaterSource] = useState('rain_fed');
  const [soilPH, setSoilPH]         = useState('');
  const [soilType, setSoilType]     = useState('');
  const [imageUri, setImageUri]     = useState(null);
  const [loading, setLoading]       = useState(false);
  const [locLoading, setLocLoading] = useState(false);
  const [useMl, setUseMl]           = useState(true);

  // ── Location ──────────────────────────────────────────────────────────

  const detectLocation = async () => {
    setLocLoading(true);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission denied', t('errorLocation'));
        return;
      }
      const loc = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });
      setLatitude(loc.coords.latitude.toFixed(6));
      setLongitude(loc.coords.longitude.toFixed(6));
    } catch (e) {
      Alert.alert('Error', t('errorLocation'));
    } finally {
      setLocLoading(false);
    }
  };

  // ── Photo upload ──────────────────────────────────────────────────────

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 0.7,
    });
    if (!result.canceled) setImageUri(result.assets[0].uri);
  };

  const takePhoto = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission denied', 'Camera access is required to take photos.');
      return;
    }
    const result = await ImagePicker.launchCameraAsync({
      allowsEditing: true,
      aspect: [4, 3],
      quality: 0.7,
    });
    if (!result.canceled) setImageUri(result.assets[0].uri);
  };

  // ── Submit ────────────────────────────────────────────────────────────

  const handleAnalyze = async () => {
    if (!latitude || !longitude) {
      Alert.alert('Missing info', t('errorLocation'));
      return;
    }
    if (!landSize || isNaN(parseFloat(landSize))) {
      Alert.alert('Missing info', 'Please enter a valid land size.');
      return;
    }

    setLoading(true);
    try {
      const result = await analyzeLand({
        latitude: parseFloat(latitude),
        longitude: parseFloat(longitude),
        landSizeHa: parseFloat(landSize),
        waterSource,
        soilPH: soilPH ? parseFloat(soilPH) : null,
        soilType: soilType || null,
        language: lang,
        topK: 5,
        useMlBlend: useMl,
        imageUri,
      });
      await saveLastResult(result);
      navigation.navigate('Results', { result, lang });
    } catch (err) {
      if (err.message === 'offline_no_cache') {
        Alert.alert(t('errorNoInternet'), 'No cached results available.');
      } else {
        Alert.alert(t('errorGeneral'), err.message || 'Unknown error');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>

      {/* ── Header ── */}
      <View style={styles.header}>
        <Text style={styles.appName}>{t('appName')}</Text>
        <Text style={styles.tagline}>{t('appTagline')}</Text>

        {/* Language toggle */}
        <TouchableOpacity
          style={styles.langToggle}
          onPress={() => setLang(lang === 'en' ? 'ta' : 'en')}
        >
          <Ionicons name="language" size={18} color="#fff" />
          <Text style={styles.langToggleText}>
            {lang === 'en' ? 'தமிழ்' : 'English'}
          </Text>
        </TouchableOpacity>
      </View>

      {/* ── Location ── */}
      <View style={styles.card}>
        <Text style={styles.label}>{t('locationLabel')}</Text>
        <View style={styles.row}>
          <TextInput
            style={[styles.input, { flex: 1, marginRight: 6 }]}
            placeholder="Latitude"
            value={latitude}
            onChangeText={setLatitude}
            keyboardType="numeric"
          />
          <TextInput
            style={[styles.input, { flex: 1 }]}
            placeholder="Longitude"
            value={longitude}
            onChangeText={setLongitude}
            keyboardType="numeric"
          />
        </View>
        <TouchableOpacity style={styles.locButton} onPress={detectLocation}>
          {locLoading ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <>
              <Ionicons name="locate" size={16} color="#fff" />
              <Text style={styles.locButtonText}>{t('detectLocation')}</Text>
            </>
          )}
        </TouchableOpacity>
      </View>

      {/* ── Land Details ── */}
      <View style={styles.card}>
        <Text style={styles.label}>{t('landSizeLabel')}</Text>
        <TextInput
          style={styles.input}
          placeholder={t('landSizePlaceholder')}
          value={landSize}
          onChangeText={setLandSize}
          keyboardType="decimal-pad"
        />

        <Text style={styles.label}>{t('waterSourceLabel')}</Text>
        <View style={styles.row}>
          {WATER_SOURCES.map((ws) => (
            <TouchableOpacity
              key={ws}
              style={[
                styles.waterBtn,
                waterSource === ws && styles.waterBtnActive,
              ]}
              onPress={() => setWaterSource(ws)}
            >
              <Text
                style={[
                  styles.waterBtnText,
                  waterSource === ws && styles.waterBtnTextActive,
                ]}
              >
                {WATER_SOURCE_LABELS[ws][lang]}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={styles.label}>{t('soilPHLabel')}</Text>
        <TextInput
          style={styles.input}
          placeholder={t('soilPHPlaceholder')}
          value={soilPH}
          onChangeText={setSoilPH}
          keyboardType="decimal-pad"
        />

        <Text style={styles.label}>{t('soilTypeLabel')}</Text>
        <TextInput
          style={styles.input}
          placeholder="e.g. loam, clay, sandy_loam"
          value={soilType}
          onChangeText={setSoilType}
        />
      </View>

      {/* ── Photo Upload ── */}
      <View style={styles.card}>
        <Text style={styles.label}>{t('uploadPhotoLabel')}</Text>
        <View style={styles.row}>
          <TouchableOpacity style={[styles.photoBtn, { marginRight: 8 }]} onPress={pickImage}>
            <Ionicons name="image-outline" size={18} color="#2D6A4F" />
            <Text style={styles.photoBtnText}>{t('uploadPhotoButton')}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.photoBtn} onPress={takePhoto}>
            <Ionicons name="camera-outline" size={18} color="#2D6A4F" />
            <Text style={styles.photoBtnText}>{t('takePhotoButton')}</Text>
          </TouchableOpacity>
        </View>
        {imageUri && (
          <Image source={{ uri: imageUri }} style={styles.preview} />
        )}
      </View>

      {/* ── ML toggle ── */}
      <View style={[styles.card, styles.row, { justifyContent: 'space-between' }]}>
        <Text style={styles.label}>Blend ML yield model</Text>
        <Switch value={useMl} onValueChange={setUseMl} thumbColor="#2D6A4F" />
      </View>

      {/* ── Submit ── */}
      <TouchableOpacity
        style={[styles.analyzeBtn, loading && styles.analyzeBtnDisabled]}
        onPress={handleAnalyze}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={styles.analyzeBtnText}>{t('analyzeButton')}</Text>
        )}
      </TouchableOpacity>

    </ScrollView>
  );
}

const BRAND = '#2D6A4F';

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F1F8F5' },
  content: { padding: 16, paddingBottom: 40 },

  header: {
    backgroundColor: BRAND,
    borderRadius: 12,
    padding: 20,
    marginBottom: 16,
    alignItems: 'center',
  },
  appName: { fontSize: 24, fontWeight: 'bold', color: '#fff' },
  tagline: { fontSize: 13, color: '#B7E4C7', marginTop: 4, textAlign: 'center' },
  langToggle: {
    flexDirection: 'row', alignItems: 'center',
    marginTop: 12, backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20,
  },
  langToggleText: { color: '#fff', marginLeft: 6, fontWeight: '600' },

  card: {
    backgroundColor: '#fff', borderRadius: 10,
    padding: 16, marginBottom: 14,
    shadowColor: '#000', shadowOpacity: 0.06,
    shadowRadius: 6, elevation: 2,
  },

  label: { fontSize: 13, fontWeight: '600', color: '#374151', marginBottom: 6, marginTop: 8 },
  input: {
    borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8,
    padding: 10, fontSize: 14, color: '#111827', backgroundColor: '#F9FAFB',
  },

  row: { flexDirection: 'row', flexWrap: 'wrap' },

  locButton: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    backgroundColor: BRAND, borderRadius: 8, padding: 10, marginTop: 10,
  },
  locButtonText: { color: '#fff', marginLeft: 6, fontWeight: '600' },

  waterBtn: {
    borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8,
    paddingHorizontal: 10, paddingVertical: 8, marginRight: 8, marginTop: 4,
    backgroundColor: '#F9FAFB',
  },
  waterBtnActive: { borderColor: BRAND, backgroundColor: '#D8F3DC' },
  waterBtnText: { fontSize: 12, color: '#6B7280' },
  waterBtnTextActive: { color: BRAND, fontWeight: '700' },

  photoBtn: {
    flexDirection: 'row', alignItems: 'center',
    borderWidth: 1, borderColor: BRAND, borderRadius: 8,
    paddingHorizontal: 12, paddingVertical: 8, marginTop: 8,
  },
  photoBtnText: { color: BRAND, marginLeft: 6, fontWeight: '600', fontSize: 13 },
  preview: { width: '100%', height: 150, borderRadius: 8, marginTop: 10 },

  analyzeBtn: {
    backgroundColor: BRAND, borderRadius: 10,
    padding: 16, alignItems: 'center', marginTop: 6,
  },
  analyzeBtnDisabled: { backgroundColor: '#95C9AB' },
  analyzeBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});
