/**
 * App.js
 * ======
 * Root component — navigation setup, language context provider.
 */

import React, { createContext, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';

import HomeScreen    from './src/screens/HomeScreen';
import ResultsScreen from './src/screens/ResultsScreen';
import DetailScreen  from './src/screens/DetailScreen';
import SearchScreen  from './src/screens/SearchScreen';

// ---------------------------------------------------------------------------
// Language Context — shared across all screens
// ---------------------------------------------------------------------------
export const LanguageContext = createContext({
  lang: 'en',
  setLang: () => {},
});

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const BRAND = '#2D6A4F';

function HomeStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: BRAND },
        headerTintColor: '#fff',
        headerTitleStyle: { fontWeight: 'bold' },
      }}
    >
      <Stack.Screen name="Home"    component={HomeScreen}    options={{ title: 'Crop DSS' }} />
      <Stack.Screen name="Results" component={ResultsScreen} options={{ title: 'Recommendations' }} />
      <Stack.Screen name="Detail"  component={DetailScreen}  options={{ title: 'Crop Details' }} />
    </Stack.Navigator>
  );
}

function SearchStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: BRAND },
        headerTintColor: '#fff',
      }}
    >
      <Stack.Screen name="Search"     component={SearchScreen} options={{ title: 'Search Crops' }} />
      <Stack.Screen name="CropDetail" component={DetailScreen} options={{ title: 'Crop Details' }} />
    </Stack.Navigator>
  );
}

export default function App() {
  const [lang, setLang] = useState('en');

  return (
    <LanguageContext.Provider value={{ lang, setLang }}>
      <NavigationContainer>
        <StatusBar style="light" />
        <Tab.Navigator
          screenOptions={({ route }) => ({
            headerShown: false,
            tabBarActiveTintColor: BRAND,
            tabBarInactiveTintColor: '#9CA3AF',
            tabBarStyle: { borderTopColor: '#E5E7EB' },
            tabBarIcon: ({ focused, color, size }) => {
              const icons = {
                HomeTab:   focused ? 'home'        : 'home-outline',
                SearchTab: focused ? 'search'      : 'search-outline',
              };
              return <Ionicons name={icons[route.name]} size={size} color={color} />;
            },
          })}
        >
          <Tab.Screen name="HomeTab"   component={HomeStack}   options={{ title: 'Analyze' }} />
          <Tab.Screen name="SearchTab" component={SearchStack} options={{ title: 'Search' }} />
        </Tab.Navigator>
      </NavigationContainer>
    </LanguageContext.Provider>
  );
}
